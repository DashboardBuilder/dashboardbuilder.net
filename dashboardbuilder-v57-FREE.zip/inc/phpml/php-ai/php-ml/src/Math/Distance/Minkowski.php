<?php

declare(strict_types=1);

namespace Phpml\Math\Distance;

/**
 * Class Minkowski
 *
 * L^n Metric.
 */
class Minkowski extends Distance
{
}
