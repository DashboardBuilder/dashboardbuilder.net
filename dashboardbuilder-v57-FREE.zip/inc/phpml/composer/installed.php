<?php return array(
    'root' => array(
        'pretty_version' => '1.0.0+no-version-set',
        'version' => '1.0.0.0',
        'type' => 'library',
        'install_path' => __DIR__ . '/../../',
        'aliases' => array(),
        'reference' => NULL,
        'name' => '__root__',
        'dev' => true,
    ),
    'versions' => array(
        '__root__' => array(
            'pretty_version' => '1.0.0+no-version-set',
            'version' => '1.0.0.0',
            'type' => 'library',
            'install_path' => __DIR__ . '/../../',
            'aliases' => array(),
            'reference' => NULL,
            'dev_requirement' => false,
        ),
        'php-ai/php-ml' => array(
            'pretty_version' => '0.9.0',
            'version' => '0.9.0.0',
            'type' => 'library',
            'install_path' => __DIR__ . '/../php-ai/php-ml',
            'aliases' => array(),
            'reference' => 'fd8b70629e16ed67307fe150ba25738449b9a6b2',
            'dev_requirement' => false,
        ),
    ),
);
