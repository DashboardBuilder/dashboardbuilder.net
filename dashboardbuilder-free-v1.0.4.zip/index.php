<?php include('top.php');?>
<?php include ('left-nav.php');?>

	
	
		<h1>Build your dashboard in a minute, no programming skill requried.</h2>
		<h3> Dashboard Builder helps you to build your dashboard in 4 easy steps.</h3>
		<div class="row">
		<div class="col-lg-12">
			<div class="col-lg-6">
				<img src="assets/img/step1.jpg" style="height:50%; width:50%;"/>
			</div>
			<div class="col-lg-6">
				<img src="assets/img/step2.jpg" style="height:50%; width:50%;"/>
			</div>
		</div>
		<p>&nbsp;</p>
		<div class="col-lg-12">
			<div class="col-lg-6">
				<img src="assets/img/step3.jpg" style="height:50%; width:50%;"/>
			</div>
			<div class="col-lg-6">
				<img src="assets/img/step4.jpg" style="height:50%; width:50%;"/>
			</div>
		</div>
		</div>
	

<?php include ('bottom.php');?>