<?php 
/*------------------------------------------------------------------------
# version 1.0 DashboardPHP 
# ------------------------------------------------------------------------
 * @author Diginix Technologies www.diginixtedh.com
 * @link http://www.dashboardbuilder.net
 * @copyright (C) 2017 Dashboardbuilder.net
 * @license: license.txt
**/

class dashboardbuilder
{
	var $type;
	var $data;
	var $title;
	var $xaxis;
	var $yaxis;
	var $xlabel;
	var $ylabel;
	var $width;
	var $height;	
	var $xaxistitle;
	var $yaxistitle;
	var $barmode;
	var $name;
	var $tracename;
	var $orientation;
	var $bubblesize;
	var $bubbletext;
	var $showgrid;
	var $showline;
	var $hole;
	var $csv;
	var $csvdata;
	var $servername;
	var $username;
	var $password;
	var $dbname;
	var $source;
	var $rdbms;
	var $mapdata=array();
	var $mapcode=array();
	var $mapcountry=array();
	

	function dashboardbuilder()
		{
			$this->type = "";
			$this->width = "";
			$this->height = "";
			$this->xaxis = array();
			$this->yaxis = array();
			$this->tracename = array();
			$this->sql = array();
			$this->xlabel = "";
			$this->ylabel = "";
			$this->title = "";	
			$this->xaxistitle = "";	
			$this->yaxistitle = "";	
			$this->barmode = "";
			$this->name = "";
			$this->orientation = "";
			$this->bubblesize = array();
			$this->bubbletext = array();
			$this->showgrid="";
			$this->showline="";
			$this->hole="";
			$this->csv="";
			$this->csvdata="";
			$this->servername = "";
			$this->username = "";
			$this->password = "";
			$this->dbname = "";
			$this->source="";
			$this->rdbms="";
		}
		
	function result()
		{
		// setting default values
		ob_start();

			// DB module
			if ($this->source=='Database'){
			
			//for FREE Version 
			if (!($this->rdbms == 'mysql')) {  // FREE Verion
				if (!($this->rdbms == 'sqlite')) {
					echo "FREE version doens't ".$this->rdbms;
					return;
				}
			}
			// for FREE version
			
			if (!$this->dbname==''){
			//$conn = new mysqli($this->servername,$this->username,$this->password,$this->dbname);
			$DB_TYPE = $this->rdbms; //Type of database<br>
			$DB_HOST = $this->servername; //Host name<br>
			$DB_USER = $this->username; //Host Username<br>
			$DB_PASS = $this->password; //Host Password<br>
			$DB_NAME = $this->dbname; //Database name<br><br>
			$SERVER='host=';
			$DATABASE='dbname=';
			
			if ($DB_TYPE=='sqlsrv') {
				$SERVER='Server=';
				$DATABASE='Database=';
			}

			try{
					if ($DB_TYPE=='sqlite'){
						$conn = new PDO("$DB_TYPE:$DB_NAME");
					}
					else {
						$conn = new PDO("$DB_TYPE:host=$DB_HOST; dbname=$DB_NAME;", $DB_USER, $DB_PASS);
					}
				} catch(Exception $e){
					echo $e;
					return;
					}

				$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
				for ($j=0;$j<count($this->sql);$j++){
					$i=0;
					if(!empty($this->sql[$j]))  {
					   try{
					   
					   if ($this->type=='map') {
						   foreach ($conn->query($this->sql[$j]) as $row) {
									$mapdata[$j][$i]= $row['DATA'];
									$mapcountry[$j][$i]= $row['COUNTRY'];
									$mapcode[$j][$i]= $row['CODE'];
									$i++;
								}
					   }
					   else {
							foreach ($conn->query($this->sql[$j]) as $row) {
								$this->xaxis[$j][$i]= $row['xaxis'];
								if (!($this->type=='histogram')){
									$this->yaxis[$j][$i]= $row['yaxis'];
								}
								$i++;
							} // for each
						
						} // else map end
						} //try
						
						catch(Exception $e){
							echo $e;
							return;
							} //catch					
					}// for count
				} // if end
			} // if end
			} // function end
			/////		
			
		$defaultcharttitle = ucwords($this->type) . " Chart";
		if ($this->title==''){ $this->title = $defaultcharttitle ;}
		if ($this->xaxistitle==''){ $this->xaxistitle ='X-axis';}
		if ($this->yaxistitle==''){ $this->yaxistitle ='Y-axis';}
		if ($this->width==''){ $this->width =100;}
		if ($this->height==''){ $this->height =100;}
		if ($this->barmode==''){ $this->barmode = 'group';}
		if ($this->name==''){ $this->name= $this->type;}
		if ($this->hole==''){ $this->hole =0;}
		if ($this->showgrid==''){ $this->showgrid= 'true';}
		if ($this->showline==''){ $this->showline= 'true';}
		if ($this->type =='stack'){$this->type ='bar';$this->barmode = "stack";} // set value for stack
		if ($this->type =='donut'){$this->type ='pie'; $this->hole=.4;} // set value for donut
		
		?>
		
  		<div id="<?php echo $this->name;?>"><!-- chart will be drawn inside this DIV --></div>
		<script>
		(function() {
			var d3 = Plotly.d3;
			
			var WIDTH_IN_PERCENT_OF_PARENT = <?php echo $this->width;?>,
				HEIGHT_IN_PERCENT_OF_PARENT = <?php echo $this->height;?>;
			
			var gd3 = d3.select('#<?php echo $this->name;?>')
				.append('div')
				.style({
					width: WIDTH_IN_PERCENT_OF_PARENT + '%',
					'margin-left': (100 - WIDTH_IN_PERCENT_OF_PARENT) / 1.5 + '%',
			
					height: HEIGHT_IN_PERCENT_OF_PARENT + 'vh',
					'margin-top': (100 - HEIGHT_IN_PERCENT_OF_PARENT) / 1.5 + 'vh'
				});
			
			var gd = gd3.node();		
			
		<?php 
		
		// Chart type Line and Bar Start //
		    if ($this->type=='line' || $this->type=='bar' ) 
				{
				if (!(count($this->xaxis)==count($this->yaxis))){
					trigger_error("X-axis and Y-axis data must be same", E_USER_ERROR);
					return $str;
					return(true);
				   }
					?>
					
					<?php
					$j=0;
					foreach ($this->xaxis as $i) {
						$j++;
						?>
						var trace<?php echo $j;?> = {
																	
						  x: <?php echo json_encode($i);?>, 
						  y: <?php echo json_encode($this->yaxis[$j-1]);?>, 
						  <?php 
						  if (!empty($this->tracename[$j-1])){echo 'name:"'.$this->tracename[$j-1].'",';}
						  ?>
						   line: {shape: 'spline'},  //{shape: 'vhv'}, {shape: 'hvh'},{shape: 'vh'},{shape: 'hv'},
						  <?php if ($this->orientation=='h'){echo "orientation: 'h',";}?>
						  	type: '<?php echo $this->type;?>'
						};
						<?php 
						}// foreach end
					?>
					var data = [<?php for ($i=1;$i<$j+1;$i++){ echo 'trace'.$i.',';}?>];
					
					var layout = {
					 title: '<?php echo $this->title ;?>',
					  xaxis: {
						title: '<?php echo $this->xaxistitle;?>', 
						showticklabels:true,
						showgrid: <?php echo $this->showgrid;?>, 
						showline: <?php echo $this->showline;?>
					  }, 
					  yaxis: {
						title: '<?php echo $this->yaxistitle;?>', 
						showticklabels:true,
						showgrid: <?php echo $this->showgrid;?>, 
						showline: <?php echo $this->showline;?>
					  },
					  barmode: '<?php echo $this->barmode;?>'
					};
					
				<?php
				} ?>

				
				///////
					var modeBarManage = {
					modeBarButtonsToRemove: ['sendDataToCloud'],
					displaylogo: false};
					Plotly.plot(gd, data, layout, modeBarManage);
					
					window.addEventListener('resize', function() { Plotly.Plots.resize(gd); });
					})();
					</script>
		<?php
		$str = ob_get_clean();
		return $str;
		}
}

?>