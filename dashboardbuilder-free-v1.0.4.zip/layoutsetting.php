<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <title>Layout setting</title>  
</head>
<body>

 <!-- Modal -->
 
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true" onclick="javascript:window.location.reload()">&times;</button>
                 <h4 class="modal-title">Chart Settings</h4>
            </div>			<!-- /modal-header -->
			<?php 
			$col = 'col'.$_GET['col'];

			if (isset($_GET['task'])) {
					if ($_GET["task"]=='save'){
						savedata($col);
						header('Location: ' . $_SERVER["HTTP_REFERER"] );
					}
				}
			
			$xmlDoc=simplexml_load_file('data/data.xml');
			$type = $xmlDoc->$col->type;
			$rdbms = $xmlDoc->$col->rdbms;
			if  (!($type=='bubble')){?>
				<script>
					document.getElementById("IDbubble").style.display="none";
					document.getElementById('bubblesize').required = false;
					document.getElementById('bubbletext').required = false;
					$('#bubblesize').get(0).setCustomValidity('');
					$('#bubbletext').get(0).setCustomValidity('');
				</script>
			<?php }
			if  ($type=='histogram'){?>
				<script>
				document.getElementById("IDyaxis").style.display="none";
				document.getElementById('yaxis').required = false;
				$('#yaxis').get(0).setCustomValidity('');
				</script>
			<?php }
			
			$title = $xmlDoc->$col->title;

			?>
			<form id="layoutsetting" class="form-horizontal" action="layoutsetting.php?task=save&layout=<?php echo $_GET['layout'];?>&col=<?php echo $_GET['col'];?>" method="post" onsubmit="return validateForm();">
			<fieldset>
			 </br>
			 <div class="form-group ">
				  <label for="sel1" class="col-sm-3  control-label"> Type:</label>
				  <div class="col-sm-6">
				  <select class="form-control" id="type" name="type" value="<?php echo $type;?>" onchange="mySelection()">
				  	<option value="line" <?php if ($type=='line'){?> selected <?php }?>>Line</option>
					<option value="bar" <?php if ($type=='bar'){?> selected <?php }?>>Bar</option>
					<option value="stack" <?php if ($type=='stack'){?> selected <?php }?> disabled>Stack</option>
					<option value="histogram" <?php if ($type=='histogram'){?> selected <?php }?> disabled>Histogram</option>
					<option value="area" <?php if ($type=='area'){?> selected <?php }?> disabled>Area</option>
					<option value="pie" <?php if ($type=='pie'){?> selected <?php }?> disabled>Pie</option>
					<option value="donut" <?php if ($type=='donut'){?> selected <?php }?> disabled>Donut</option>
					<option value="bubble" <?php if ($type=='bubble'){?> selected <?php }?> disabled>Bubble</option>
					<option value="map" <?php if ($type=='map'){?> selected <?php }?> disabled>Choropleth Map</option>
				  </select>
				  </div>
				</div>
			
			<div class="modal-body">
			
			<!-- Tab Panel starts -->
			<ul class="nav nav-tabs">
			  <li class="active" ><a data-toggle="tab" href="#home" >&nbsp;&nbsp;&nbsp;&nbsp; Data Source &nbsp;&nbsp;&nbsp;&nbsp;</a></li>
			  <li><a data-toggle="tab" href="#menu1">   Properties</a></li>
			  <li><a data-toggle="tab" href="#menu2">   Optional</a></li>
			</ul>

			<div class="tab-content">
			<!-- Tab for Data Source -->
			  <div id="home" class="tab-pane fade in active">
			  <?php if($xmlDoc->$col->source=="Data"){?>
				  <script type="text/javascript">
				  	document.getElementById('host').required = false;
					document.getElementById('user').required = false;
					document.getElementById('db').required = false;
					document.getElementById('sql').required = false;
					$('#host').get(0).setCustomValidity('');
					$('#user').get(0).setCustomValidity('');
					$('#db').get(0).setCustomValidity('');
					$('#sql').get(0).setCustomValidity('');
					
					document.getElementById('xaxis').required = true;
					if (!(document.getElementById('type').value=='histogram')){
				   		document.getElementById('yaxis').required = true;
				   }
				  </script>
			  <?php } else {?>
			  	  <script type="text/javascript">
					document.getElementById('host').required = true;
					document.getElementById('user').required = true;
					document.getElementById('db').required = true;
					document.getElementById('sql').required = true;
					
					document.getElementById('xaxis').required = false;
					document.getElementById('yaxis').required = false;
					$('#xaxis').get(0).setCustomValidity('');
					$('#yaxis').get(0).setCustomValidity('');
				  </script>
			 <?php }?>
			 
			 <?php if  ($rdbms=='sqlite'){?>
				<script>
					document.getElementById('hostID').style.display="none";
					document.getElementById('host').required = false;
					document.getElementById('userID').style.display="none";
					document.getElementById('user').required = false;
					$('#host').get(0).setCustomValidity('');
					$('#user').get(0).setCustomValidity('');
				</script>
			<?php } ?>
			
			  		<div class="radio-inline">
						<input type="radio" name="source" value="Database" onClick="show_hide('Database', 'Data')" <?php if(!($xmlDoc->$col->source=="Data")){ echo 'checked';$database="block";$data="none";}?>  />Database
					</div>
					<div class="radio-inline">
						<input type="radio" name="source" value="Data" onClick="show_hide('Data', 'Database')"  <?php if(($xmlDoc->$col->source=="Data")){ echo 'checked'; $database="none";$data="block";}?> />Data
					</div>
					<p>&nbsp;</p>
					<div id="Database" style="display: <?php echo $database;?>;">
					<!-- Database connection -->
						<label  class="col-sm-3 control-label">Database:</label>
						  <div class="col-sm-offset-3" style="width:200px; ">
						  <select class="form-control" id="rdbms" name="rdbms" value="<?php echo $rdbms;?>" onchange="DBSelection()">
							<option value="mysql" <?php if (($rdbms=='mysql') || ($rdbms=='')){?> selected <?php }?>>MySQL</option>
							<option value="sqlite" <?php if ($rdbms=='sqlite'){?> selected <?php }?>>SQLite</option>
							<option value="sqlsrv" <?php if ($rdbms=='sqlsrv'){?> selected <?php }?> disabled>MS SQL Server</option>
							<option value="dblib" <?php if ($rdbms=='dblib'){?> selected <?php }?> disabled>Sybase</option>
							<option value="pgsql" <?php if ($rdbms=='pgsql'){?> selected <?php }?> disabled>PostgreSQL</option>
							<option value="oci" <?php if ($rdbms=='oci'){?> selected <?php }?> disabled>Oracle</option>
							<option value="cubrid" <?php if ($rdbms=='cubrid'){?> selected <?php }?> disabled>Cubrid</option>
						  </select>
						  </div>
						  <br/>
						<div id="hostID">  
					  	<label class="col-sm-3 control-label">Host:</label> 
						<div class="col-sm-offset-3">
						   <input type="text" id="host" name="host" value="<?php echo $xmlDoc->$col->host;?>" placeholder="localhost" size="50" required oninvalid="this.setCustomValidity('Please enter Host name')" oninput="setCustomValidity('')"/>    
						</div><br/>
						</div>
						
						<div id="userID">
						<label class="col-sm-3 control-label">User:</label> 
						<div class="col-sm-offset-3">
						   <input type="text" id="user" name="user" value="<?php echo $xmlDoc->$col->user;?>" placeholder="root" size="50" required oninvalid="this.setCustomValidity('Please enter user name')" oninput="setCustomValidity('')" />    
						</div><br/>
						</div>
						
						<label class="col-sm-3 control-label">Passowrd:</label> 
						<div class="col-sm-offset-3">
						   <input type="password" id="password" name="password" value="<?php echo $xmlDoc->$col->password;?>" size="50"/>    
						</div><br/>
						<label class="col-sm-3 control-label">Database Name:</label> 
						<div class="col-sm-offset-3">
						   <input type="text" id="db" name="db" value="<?php echo $xmlDoc->$col->db;?>" placeholder="northwind"size="50" required oninvalid="this.setCustomValidity('Please enter DB name')" oninput="setCustomValidity('')" />    
						</div><br/>
						
						<div class="form-group field_wrapper6">
									<label class="col-sm-3 control-label">SQL:</label> 
									<div class="col-sm-offset-3">
										<?php $i=0;				
											foreach($xmlDoc->$col->sql as $value){
											if (!empty($value)){?>
											<div>
											   <input type="text" id="sql" name="sql[]" value="<?php echo $value;?>" placeholder="select sales as xaxis, product as yaxis from sale" size="50"/> 
											   <a href="javascript:void(0);" class="add_button6" title="Add field"> <span class="fa fa-plus-square" style="font-size:26px;"></span></a>
											  <?php $i++;?>
											</div>
											<?php
											}}
											if ($i==0){?>
											   <input type="text" id="sql" name="sql[]" value="<?php echo $value;?>" placeholder="select sales as xaxis, product as yaxis from sale" size="50" required oninvalid="this.setCustomValidity('Please enter SQL statement')" oninput="setCustomValidity('')"/> 
											   <a href="javascript:void(0);" class="add_button6" title="Add field"> <span class="fa fa-plus-square" style="font-size:26px;"></span></a>
											<?php }
										?>
									</div>
						</div>

					</div>
					<div id="Data" style="display: <?php echo $data;?>;">			
								<!-- Xaxis -->
								<div class="form-group field_wrapper">
									<label class="col-sm-3 control-label">X-axis:</label> 
									<div class="col-sm-offset-3">
										<?php $i=0;				
											foreach($xmlDoc->$col->xaxis as $value){
											if (!empty($value)){?>
											<div>
											   <input type="text" id="xaxis" name="xaxis[]" value="<?php echo $value;?>" placeholder="10,20,30,40" size="50"/> 
											   <a href="javascript:void(0);" class="add_button" title="Add field"> <span class="fa fa-plus-square" style="font-size:26px;"></span></a>
											  <?php $i++;?>
											</div>
											<?php
											}}
											if ($i==0){?>
											   <input type="text" id="xaxis" name="xaxis[]" value="<?php echo $value;?>" placeholder="10,20,30,40" size="50" required oninvalid="this.setCustomValidity('Please enter X-axis data')" oninput="setCustomValidity('')" /> 
											   <a href="javascript:void(0);" class="add_button" title="Add field"> <span class="fa fa-plus-square" style="font-size:26px;" ></span></a>
											<?php }
										?>
									</div>
								</div>
								<!-- Yaxis -->
								<div id="IDyaxis">
									<div class="form-group field_wrapper2">
										<label class="col-sm-3 control-label">Y-axis:</label> 
										<div class="col-sm-offset-3">
											<?php $i=0;				
												foreach($xmlDoc->$col->yaxis as $value){
												if (!empty($value)){?>
												<div>
												   <input type="text" id="yaxis" name="yaxis[]" value="<?php echo $value;?>" placeholder="Mobile, iPod, Tab, PC" size="50"/> 
												   <a href="javascript:void(0);" class="add_button2" title="Add field"> <span class="fa fa-plus-square" style="font-size:26px;"></span></a>
												  <?php $i++;?>
												</div>
												<?php
												}}
												if ($i==0){?>
											   <input type="text" id="yaxis" name="yaxis[]" value="<?php echo $value;?>" placeholder="Mobile, iPod, Tab, PC" size="50" required oninvalid="this.setCustomValidity('Please enter Y-axis data')" oninput="setCustomValidity('')" /> 
											   <a href="javascript:void(0);" class="add_button2" title="Add field"> <span class="fa fa-plus-square" style="font-size:26px;"></span></a>
											<?php }
											?>
										</div>
									</div>
								</div>
					</div>
			  </div>
			<!-- Tab Data Source end -->
	
			<!-- Tab for Properties -->  
			  <div id="menu1" class="tab-pane fade">
				<div class="form-group">
				<br/>
						<label class="col-sm-3 control-label">Title:</label> 
						<div class="col-sm-offset-3">
						   <input type="text" id="title" name="title" value="<?php echo $title;?>" placeholder="Chart Title" size="50"/>    
						</div><br/>
						
						<label class="col-sm-3 control-label">Unique Name:</label> 
						<div class="col-sm-offset-3">
						   <input type="text" id="name" name="name" value="<?php echo $xmlDoc->$col->name;?>" placeholder="Pie1" size="50" required oninvalid="this.setCustomValidity('Please enter a Unique name')" oninput="setCustomValidity('')"/>    
						</div><br/>

						<div class="form-group field_wrapper5">
									<label class="col-sm-3 control-label">Legends</label> 
									<div class="col-sm-offset-3">
										<?php $i=0;				
											foreach($xmlDoc->$col->tracename as $value){
											if (!empty($value)){?>
											<div>
											   <input type="text" id="tracename" name="tracename[]" value="<?php echo $value;?>" placeholder="Sales" size="50"/> 
											   <a href="javascript:void(0);" class="add_button5" title="Add field"> <span class="fa fa-plus-square" style="font-size:26px;"></span></a>
											  <?php $i++;?>
											</div>
											<?php
											}}
											if ($i==0){?>
											   <input type="text" id="tracename" name="tracename[]" value="<?php echo $value;?>" placeholder="Sales" size="50"/> 
											   <a href="javascript:void(0);" class="add_button5" title="Add field"> <span class="fa fa-plus-square" style="font-size:26px;"></span></a>
											<?php }
										?>
									</div>
						</div>
						
						<!-- Bubble size -->
								<div id="IDbubble">
									<div class="form-group field_wrapper3">
										<label class="col-sm-3 control-label">Bubble size:</label> 
										<div class="col-sm-offset-3">
											<?php $i=0;				
												foreach($xmlDoc->$col->bubblesize as $value){
												if (!empty($value)){?>
												<div>
												   <input type="text" id="bubblesize" name="bubblesize[]" value="<?php echo $value;?>" placeholder="20,30,40,50" size="50"/> 
												   <a href="javascript:void(0);" class="add_button3" title="Add field"> <span class="fa fa-plus-square" style="font-size:26px;"></span></a>
												  <?php $i++;?>
												</div>
												<?php
												}}
												if ($i==0){?>
												<input type="text" id="bubblesize" name="bubblesize[]" value="<?php echo $value;?>" placeholder="20,30,40,50" size="50" required oninvalid="this.setCustomValidity('Please enter Bubble size')" oninput="setCustomValidity('')"/> 
												<a href="javascript:void(0);" class="add_button3" title="Add field"> <span class="fa fa-plus-square" style="font-size:26px;"></span></a>
												<?php }
											?>
										</div>
									</div>
								<!-- Bubble size end -->
								<!-- Bubble text -->
									<div class="form-group field_wrapper4">
										<label class="col-sm-3 control-label">Bubble text:</label> 
										<div class="col-sm-offset-3">
											<?php $i=0;				
												foreach($xmlDoc->$col->bubbletext as $value){
												if (!empty($value)){?>
												<div>
												   <input type="text" id="bubbletext" name="bubbletext[]" value="<?php echo $value;?>" placeholder="'Pizza 30%', 'Burger 44%', 'Orange 8%', 'Banana 12%'" size="50"/> 
												   <a href="javascript:void(0);" class="add_button4" title="Add field"> <span class="fa fa-plus-square" style="font-size:26px;"></span></a>
												  <?php $i++;?>
												</div>
												<?php
												}}
												if ($i==0){?>
												<input type="text" id="bubbletext" name="bubbletext[]" value="<?php echo $value;?>" placeholder="'Pizza 30%', 'Burger 44%', 'Orange 8%', 'Banana 12%'" size="50" required oninvalid="this.setCustomValidity('Please enter Bubble text')" oninput="setCustomValidity('')"/> 
												   <a href="javascript:void(0);" class="add_button4" title="Add field"> <span class="fa fa-plus-square" style="font-size:26px;"></span></a>
											<?php }
											?>
										</div>
									</div>
								</div> <!-- Bubble id -->
								<!-- Bubble Tex end -->
				</div>
			  </div>
			  <!-- Tab Properties Ends -->
			  
			  <!-- Tab Optional Start -->
			   <div id="menu2" class="tab-pane fade">
				<div class="form-group">
				<br/>
				<label class="col-sm-3 control-label">Xaxis Title:</label> 
						<div class="col-sm-offset-3">
						   <input type="text" id="xaxistitle" name="xaxistitle" value="<?php echo $xmlDoc->$col->xaxistitle;?>" placeholder="Sales" size="50"/>    
						</div><br/>
						
						<label class="col-sm-3 control-label">Yaxis Title:</label> 
						<div class="col-sm-offset-3">
						   <input type="text" id="yaxistitle" name="yaxistitle" value="<?php echo $xmlDoc->$col->yaxistitle;?>" placeholder="Products" size="50"/>    
						</div><br/>
					
						<div class="row control-label">
							<label class="col-sm-3 control-label">Height:</label> 
							<div class="col-sm-2">
							<?php $height=$xmlDoc->$col->height;?>
								<select class="form-control" id="height" name="height" value="<?php echo $height;?>" style="width:100px;" >
									<option value="100" <?php if ($height=='100'){?> selected <?php }?>>100%</option>
									<option value="90" <?php if ($height=='90'){?> selected <?php }?>>90%</option>
									<option value="80" <?php if ($height=='80'){?> selected <?php }?>>80%</option>
									<option value="70" <?php if ($height=='70'){?> selected <?php }?>>70%</option>
									<option value="60" <?php if ($height=='60'){?> selected <?php }?>>60%</option>
									<option value="50" <?php if ($height=='50'){?> selected <?php }?>>50%</option>
									<option value="40" <?php if ($height=='40'){?> selected <?php }?>>40%</option>
									<option value="30" <?php if ($height=='30'){?> selected <?php }?>>30%</option>
								</select>
							</div>
							<label class="col-sm-2">Width:</label> 
							<div class="col-sm-2">
							<?php $width=$xmlDoc->$col->width;?>
								<select class="form-control" id="width" name="width" value="<?php echo $width;?>" style="width:100px;" >
									<option value="100" <?php if ($width=='100'){?> selected <?php }?>>100%</option>
									<option value="90" <?php if ($width=='90'){?> selected <?php }?>>90%</option>
									<option value="80" <?php if ($width=='80'){?> selected <?php }?>>80%</option>
									<option value="70" <?php if ($width=='70'){?> selected <?php }?>>70%</option>
									<option value="60" <?php if ($width=='60'){?> selected <?php }?>>60%</option>
									<option value="50" <?php if ($width=='50'){?> selected <?php }?>>50%</option>
									<option value="40" <?php if ($width=='40'){?> selected <?php }?>>40%</option>
									<option value="30" <?php if ($width=='30'){?> selected <?php }?>>30%</option>
								</select>
							</div>
						</div>	
						<br/>
						<label class="col-sm-3 control-label">Showgrid:</label> 
						<div class="col-sm-offset-3">  
						    <div class="radio-inline">
								<input type="radio" name="showgrid" value="true" <?php if(!($xmlDoc->$col->showgrid=="false")){ echo 'checked';}?> />Show 
							</div>
							<div class="radio-inline">
								<input type="radio" name="showgrid" value="false" <?php if($xmlDoc->$col->showgrid=="false"){ echo 'checked';}?> />Hide
							</div> 
						</div>
					    
						<label class="col-sm-3 control-label">Showline:</label> 
						<div class="col-sm-offset-3">  
						    <div class="radio-inline">
								<input type="radio" name="showline" value="true" <?php if(!($xmlDoc->$col->showline=="false")){ echo 'checked';}?> />Show 
							</div>
							<div class="radio-inline">
								<input type="radio" name="showline" value="false" <?php if($xmlDoc->$col->showline=="false"){ echo 'checked';}?> />Hide
							</div> 
						</div>
						
						<label class="col-sm-3 control-label">Orientation:</label> 
						<div class="col-sm-offset-3">  
						    <div class="radio-inline">
								<input type="radio" name="orientation" value="h" <?php if($xmlDoc->$col->orientation=='h'){ echo 'checked';}?> />Horizontal 
							</div>
							<div class="radio-inline">
								<input type="radio" name="orientation" value="v" <?php if(!($xmlDoc->$col->orientation=='h')){ echo 'checked';}?> />Vertical
							</div> 
						</div> 
				
				</div>
			   </div>
			  <!-- Tab Opotional Ends -->
			  
			</div>
			<!-- Tab Panel Ends -->

			<div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" onclick="javascript:window.location.reload()">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
			</fieldset>
			</form>
			</div>			<!-- /modal-body -->

</body>
</html>

<?php
function savedata($col) {
	// $xmlfile = 'data/layout'.$_GET['layout'].'.xml';
	 $xmlfile = 'data/data.xml';
	 $xmlDoc=simplexml_load_file($xmlfile);
	 $xmlDoc->$col->type = $_POST['type'];
	 $xmlDoc->$col->source = $_POST['source'];
	 
	 if ($_POST['source']=='Database'){
	 	$xmlDoc->$col->rdbms = $_POST['rdbms'];
	 }
	 
	 if (!empty($_POST['host'])){
	 	$xmlDoc->$col->host = $_POST['host'];
		}
		
	if (!empty($_POST['user'])){
	 	$xmlDoc->$col->user = $_POST['user'];
		}
		
	if (!empty($_POST['password'])){
	 	$xmlDoc->$col->password = $_POST['password'];
		}
		
	if (!empty($_POST['db'])){
	 	$xmlDoc->$col->db = $_POST['db'];
		}
	 
	 if (!empty($_POST['xaxis'])){
	 $i=0;
	 foreach($_POST['xaxis'] as $value){
      $xmlDoc->$col->xaxis[$i] = $value;
	  $i++;
	 }
	 }

	if (!empty($_POST['yaxis'])){
	 $i=0;
	 foreach($_POST['yaxis'] as $value){
      $xmlDoc->$col->yaxis[$i] = $value;
	  $i++;
	 }
	 }
	 
	 if (!empty($_POST['sql'])){
	 $i=0;
	 foreach($_POST['sql'] as $value){
      $xmlDoc->$col->sql[$i] = $value;
	  $i++;
	 }
	 }

	 if ($_POST['type']=='bubble'){
	 $i=0;
	 foreach($_POST['bubblesize'] as $value){
      $xmlDoc->$col->bubblesize[$i] = $value;
	  $i++;
	 }
	 
	 $i=0;
	 foreach($_POST['bubbletext'] as $value){
      $xmlDoc->$col->bubbletext[$i] = $value;
	  $i++;
	 }
	 }
	 
	 if (!empty($_POST['tracename'])){
	  $i=0;
	 foreach($_POST['tracename'] as $value){
      $xmlDoc->$col->tracename[$i] = $value;
	  $i++;
	 }}
	 
	 $xmlDoc->$col->title = $_POST['title'];
	 $xmlDoc->$col->name = $_POST['name'];
	 $xmlDoc->$col->xaxistitle = $_POST['xaxistitle'];
	 $xmlDoc->$col->yaxistitle = $_POST['yaxistitle'];
	 $xmlDoc->$col->height = $_POST['height'];
	 $xmlDoc->$col->width = $_POST['width'];
	 $xmlDoc->$col->showgrid = $_POST['showgrid'];
	 $xmlDoc->$col->showline = $_POST['showline'];
	 
	 $xmlDoc->$col->orientation = $_POST['orientation'];
	  
	 $xmlDoc->asXML($xmlfile);
}
?> 

<script>
function mySelection() {

    var x = document.getElementById("type").value;

	if(x === 'bubble'){ //Check if bubble is selected
            document.getElementById('IDbubble').style.display="block";
			document.getElementById('bubblesize').required = true;
			document.getElementById('bubbletext').required = true;
			}
			else {
			document.getElementById('IDbubble').style.display="none";
			document.getElementById('bubbletext').required = false;
			document.getElementById('bubblesize').required = false;
			$('#bubbletext').get(0).setCustomValidity('');
			$('#bubblesize').get(0).setCustomValidity('');
     }
		if (document.getElementById("source").value === "Data") {
			if(x === 'histogram'){ //Check if histogram is selected
				document.getElementById('IDyaxis').style.display="none";
				document.getElementById('yaxis').required = false;
				$('#yaxis').get(0).setCustomValidity('');
				}
				else {
				document.getElementById('IDyaxis').style.display="block";
				document.getElementById('yaxis').required = true;
			}		
		}
}
</script>

<script>
function DBSelection() {

	var x = document.getElementById("rdbms").value;

	if(x === 'sqlite'){ //Check if SQLite is selected
            document.getElementById('hostID').style.display="none";
			document.getElementById('host').required = false;
			document.getElementById('userID').style.display="none";
			document.getElementById('user').required = false;
			$('#host').get(0).setCustomValidity('');
			$('#user').get(0).setCustomValidity('');
			}
			else {
			document.getElementById('hostID').style.display="block";
			document.getElementById('host').required = true;
			document.getElementById('userID').style.display="block";
			document.getElementById('user').required = true;    
			 }
}
</script>

<script>
function show_hide(show, hide)
	{

	document.getElementById(show).style.display="block";
	document.getElementById(hide).style.display="none";
	
	if (hide=='Database'){
		document.getElementById('host').required = false;
		document.getElementById('user').required = false;
		document.getElementById('db').required = false;
		document.getElementById('sql').required = false;
		$('#host').get(0).setCustomValidity('');
		$('#user').get(0).setCustomValidity('');
		$('#db').get(0).setCustomValidity('');
		$('#sql').get(0).setCustomValidity('');
		
		document.getElementById('xaxis').required = true;
		if (!(document.getElementById('type').value=='histogram')){
		   document.getElementById('yaxis').required = true;
		   }
		
	}
	if (show=='Database'){
	
		if (document.getElementById("rdbms").value != "sqlite") {
			document.getElementById('host').required = true;
			document.getElementById('user').required = true;
		}
		document.getElementById('db').required = true;
		document.getElementById('sql').required = true;
		
		document.getElementById('xaxis').required = false;
		document.getElementById('yaxis').required = false;
		$('#xaxis').get(0).setCustomValidity('');
		$('#yaxis').get(0).setCustomValidity('');
	}
	
	
	}
</script>

<script type="text/javascript">

$(document).ready(function(){
    var maxField = 10; //Input fields increment limitation
    var addButton = $('.add_button'); //Add button selector
    var wrapper = $('.field_wrapper'); //Input field wrapper
    var fieldHTML = '<div class="col-sm-offset-3"><input type="text" name="xaxis[]" value="" size="50"/><a href="javascript:void(0);" class="remove_button" title="Remove field"> <span class="fa fa-minus-square" style="font-size:26px;"></span></a></div>'; //New input field html 
    var x = 1; //Initial field counter is 1
    $(addButton).click(function(){ //Once add button is clicked
        if(x < maxField){ //Check maximum number of input fields
            x++; //Increment field counter
            $(wrapper).append(fieldHTML); // Add field html
        }
    });
    $(wrapper).on('click', '.remove_button', function(e){ //Once remove button is clicked
        e.preventDefault();
        $(this).parent('div').remove(); //Remove field html
        x--; //Decrement field counter
    });
});

$(document).ready(function(){
    var maxField = 10; //Input fields increment limitation
    var addButton = $('.add_button2'); //Add button selector
    var wrapper = $('.field_wrapper2'); //Input field wrapper
    var fieldHTML = '<div class="col-sm-offset-3"><input type="text" name="yaxis[]" value="" size="50"/><a href="javascript:void(0);" class="remove_button2" title="Remove field"> <span class="fa fa-minus-square" style="font-size:26px;"></span></a></div>'; //New input field html 
    var x = 1; //Initial field counter is 1
    $(addButton).click(function(){ //Once add button is clicked
        if(x < maxField){ //Check maximum number of input fields
            x++; //Increment field counter
            $(wrapper).append(fieldHTML); // Add field html
        }
    });
    $(wrapper).on('click', '.remove_button2', function(e){ //Once remove button is clicked
        e.preventDefault();
        $(this).parent('div').remove(); //Remove field html
        x--; //Decrement field counter
    });
});

$(document).ready(function(){
    var maxField = 10; //Input fields increment limitation
    var addButton = $('.add_button3'); //Add button selector
    var wrapper = $('.field_wrapper3'); //Input field wrapper
    var fieldHTML = '<div class="col-sm-offset-3"><input type="text" name="bubblesize[]" value="" size="50"/><a href="javascript:void(0);" class="remove_button3" title="Remove field"> <span class="fa fa-minus-square" style="font-size:26px;"></span></a></div>'; //New input field html 
    var x = 1; //Initial field counter is 1
    $(addButton).click(function(){ //Once add button is clicked
        if(x < maxField){ //Check maximum number of input fields
            x++; //Increment field counter
            $(wrapper).append(fieldHTML); // Add field html
        }
    });
    $(wrapper).on('click', '.remove_button3', function(e){ //Once remove button is clicked
        e.preventDefault();
        $(this).parent('div').remove(); //Remove field html
        x--; //Decrement field counter
    });
});

$(document).ready(function(){
    var maxField = 10; //Input fields increment limitation
    var addButton = $('.add_button4'); //Add button selector
    var wrapper = $('.field_wrapper4'); //Input field wrapper
    var fieldHTML = '<div class="col-sm-offset-3"><input type="text" name="bubbletext[]" value="" size="50"/><a href="javascript:void(0);" class="remove_button4" title="Remove field"> <span class="fa fa-minus-square" style="font-size:26px;"></span></a></div>'; //New input field html 
    var x = 1; //Initial field counter is 1
    $(addButton).click(function(){ //Once add button is clicked
        if(x < maxField){ //Check maximum number of input fields
            x++; //Increment field counter
            $(wrapper).append(fieldHTML); // Add field html

        }
    });
    $(wrapper).on('click', '.remove_button4', function(e){ //Once remove button is clicked
        e.preventDefault();
        $(this).parent('div').remove(); //Remove field html
        x--; //Decrement field counter
    });
});

$(document).ready(function(){
    var maxField = 10; //Input fields increment limitation
    var addButton = $('.add_button5'); //Add button selector
    var wrapper = $('.field_wrapper5'); //Input field wrapper
    var fieldHTML = '<div class="col-sm-offset-3"><input type="text" name="tracename[]" value="" size="50"/><a href="javascript:void(0);" class="remove_button5" title="Remove field"> <span class="fa fa-minus-square" style="font-size:26px;"></span></a></div>'; //New input field html 
    var x = 1; //Initial field counter is 1
    $(addButton).click(function(){ //Once add button is clicked
        if(x < maxField){ //Check maximum number of input fields
            x++; //Increment field counter
            $(wrapper).append(fieldHTML); // Add field html

        }
    });
    $(wrapper).on('click', '.remove_button5', function(e){ //Once remove button is clicked
        e.preventDefault();
        $(this).parent('div').remove(); //Remove field html
        x--; //Decrement field counter
    });
});

$(document).ready(function(){
    var maxField = 10; //Input fields increment limitation
    var addButton = $('.add_button6'); //Add button selector
    var wrapper = $('.field_wrapper6'); //Input field wrapper
    var fieldHTML = '<div class="col-sm-offset-3"><input type="text" name="sql[]" value="" size="50"/><a href="javascript:void(0);" class="remove_button6" title="Remove field"> <span class="fa fa-minus-square" style="font-size:26px;"></span></a></div>'; //New input field html 
    var x = 1; //Initial field counter is 1
    $(addButton).click(function(){ //Once add button is clicked
        if(x < maxField){ //Check maximum number of input fields
            x++; //Increment field counter
            $(wrapper).append(fieldHTML); // Add field html

        }
    });
    $(wrapper).on('click', '.remove_button6', function(e){ //Once remove button is clicked
        e.preventDefault();
        $(this).parent('div').remove(); //Remove field html
        x--; //Decrement field counter
    });
});
</script>
