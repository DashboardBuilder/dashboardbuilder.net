<script src="assets/js/dashboard.min.js"></script>
<?php 
include('top.php');
include ('left-nav.php');
include("inc/dashboard_dist.php"); 
$xml=simplexml_load_file("data/data.xml") or die("Error: Cannot create object");

// Col data
$no_col = $_REQUEST['col'];
$col = array();
$reuslt = array();
$name = array();
$height = array();

for ($j=0;$j<$no_col;$j++){
	$col = 'col'.$j;
	$data = new dashboardbuilder(); 
	
	$data->type =  $xml->$col->type; 
	$data->source =  $xml->$col->source; 
	$data->servername =  $xml->$col->host;
	$data->username =  $xml->$col->user;
	$data->password =  $xml->$col->password;
	$data->dbname =  $xml->$col->db;
	$data->rdbms =  $xml->$col->rdbms;
	
	$data->name = $xml->$col->name;
	$data->title = $xml->$col->title;
	$data->orientation = $xml->$col->orientation;
	$data->xaxistitle = $xml->$col->xaxistitle;
	$data->yaxistitle = $xml->$col->yaxistitle;
	$data->height = $xml->$col->height;
	$data->width = $xml->$col->width;
	$data->showgrid = $xml->$col->showgrid;
	$data->showline = $xml->$col->showline;
	
	$i=0;
	if ($data->type=='bubble'){
		foreach($xml->$col->bubblesize as $value){
		   $data->bubblesize[$i]=  $value;
		   $i++;
		}
		
		$i=0;
		foreach($xml->$col->bubbletext as $value){
		   $data->bubbletext[$i]= $value;
		   $i++;
		}
	}
	
	$i=0;
	if ($xml->$col->source =="Database"){
		foreach($xml->$col->sql as $value){
		   $data->sql[$i]=  $value;
		   $i++;
		}
	}
	
	$i=0;
	foreach($xml->$col->tracename as $value){
	   $data->tracename[$i]=  $value;
	   $i++;
	}
		
	$i=0;
	if (!($xml->$col->source =="Database")){
		foreach($xml->$col->xaxis as $value){
				$data->xaxis[$i]= array_map('strval', explode(',', $value));
		   $i++;
		}
	}
	
	$i=0;
	if (!($xml->$col->source =="Database")){
		foreach($xml->$col->yaxis as $value){
				$data->yaxis[$i]= array_map('strval', explode(',', $value));
		   $i++;
		}
	}
	
	$result[$j] = $data->result(); 
	$name[$j] = $data->name;
	$height[$j] = $data->height;
  
}// for end
		
if ($no_col==1){
	include ('col1.php');
	}
elseif ($no_col==2){
     if ($_REQUEST['p']==2){
		include ('col2b.php');
		}
		else{
		include ('col2.php');
		}
	}
elseif ($no_col==3){
     if ($_REQUEST['p']==2){
		include ('col3b.php');
		}
		else{
		include ('col3.php');
		}
	}
elseif ($no_col==4){
		include ('col4.php');
}

include ('bottom.php');?>