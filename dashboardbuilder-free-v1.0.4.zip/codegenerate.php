<link href="lib/jquery-linedtextarea.css" type="text/css" rel="stylesheet" />
<?php
include('top.php');
include ('left-nav.php');

if (isset($_GET['col'])) {
	    	$code = genfile($_REQUEST['col'],$_REQUEST['p']);
}
?>

<ol class="breadcrumb">
<li>
	<i class="fa fa-home"></i>  <a href="index.php"> Home</a>
</li>
<li>
	<i class="fa fa-th"></i>  Generate
</li>
<li class="active">
	PHP Code 
</li>
</ol>
<div class="col-lg-12">
<div class="panel panel-default">
	<div class="panel-heading">
	&nbsp;
	<button class="close" onClick="copypast('hiddencode')"><span class="fa fa-clipboard"></span></button>
	</div>
	<div class="panel-body">
	
			<form  id="savefil" class="form-horizontal"  method="post">
									<textarea  id="phpcode" class="lined" rows="20" hresize><?php echo $code;?></textarea>
			</form>
	</div>
</div>
	


<?php 
include ('bottom.php');

function genfile($col,$p){
$no_col = $_REQUEST['col'];
$xml=simplexml_load_file("data/data.xml") or die("Error: Cannot create object");

// Code Generate Start 
$write = '
<?php
/**
 * DashboardBuilder
 *
 * @author Diginix Technologies www.diginixtech.com
 * Support <support@dashboardbuider.net> - http://www.dashboardbuilder.net
 * @copyright (C) 2017 Dashboardbuilder.net
 * @version 1.0.1
 * @license: license.txt
 */

include("inc/dashboard_dist.php");  // copy this file to inc folder 
';

$col = array();
$reuslt = array();
$name = array();
$height = array();

for ($j=0;$j<$no_col;$j++){
	$col = 'col'.$j;

$write.='

// for chart #'.($j+1).'
$data = new dashboardbuilder(); 
$data->type =  "'.$xml->$col->type.'";'."\n";
// Check if source is Database
if ($xml->$col->source=='Database'){
$write.='
$data->source =  "'.$xml->$col->source.'"; 
$data->rdbms =  "'.$xml->$col->rdbms.'"; 
$data->servername =  "'.$xml->$col->host.'";
$data->username =  "'.$xml->$col->user.'";
$data->password =  "'.$xml->$col->password.'";
$data->dbname =  "'.$xml->$col->db.'";
';
	$i=0;
	foreach($xml->$col->sql as $value){
		if (!empty($value)){
		   $write.='$data->sql['.$i.']=  "'.$value.'";'."\n";
		   $i++;
	   }
	}
	
	} //if Database End
	else
	{
	$i=0;
	foreach($xml->$col->xaxis as $value){
		if (!empty($value)){
		   $write.='$data->xaxis['.$i.']= array_map("strval", explode(",", "'.$value.'"));'."\n";
		   $i++;
		  }
	}
	$i=0;
	foreach($xml->$col->yaxis as $value){
		if (!empty($value)){
		  $write.='$data->yaxis['.$i.']= array_map("strval", explode(",", "'.$value.'"));'."\n";
		   $i++;
		  }
	}
} // Else Database End
$write.='
$data->name = "'.$xml->$col->name.'";
$data->title = "'.$xml->$col->title.'";
$data->orientation = "'.$xml->$col->orientation.'";
$data->xaxistitle = "'.$xml->$col->xaxistitle.'";
$data->yaxistitle = "'.$xml->$col->yaxistitle.'";
$data->showgrid = "'.$xml->$col->showgrid.'";
$data->showline = "'.$xml->$col->showline.'";
$data->height = '.$xml->$col->height.';
$data->width = '.$xml->$col->width.';
';

$i=0;
	foreach($xml->$col->tracename as $value){
		if (!empty($value)){
		   $write.='$data->tracename['.$i.']=  "'.$value.'";'."\n";
		   $i++;
	   }
	}
	

$i=0;
if ($xml->$col->type=='bubble'){
	foreach($xml->$col->bubblesize as $value){
		if (!empty($value)){
		   $write.='$data->bubblesize['.$i.']=  "'.$value.'";'."\n";
		   $i++;
		}
	}
	
	$i=0;
	foreach($xml->$col->bubbletext as $value){
		if (!empty($value)){
		   $write.='$data->bubbletext['.$i.']= "'.$value.'";'."\n";
		   $i++;
	   }
	}
}// if Bubble End	
$write.='
$result['.$j.'] = $data->result();';

$name[$j]=$xml->$col->name;
$height[$j]=$xml->$col->height;
} // End For Loop

$write.='?>

<!DOCTYPE html>
<html>
<head>
	<script src="assets/js/dashboard.min.js"></script> <!-- copy this file to assets/js folder -->
	<link rel="stylesheet" href="css/bootstrap.min.css"> <!-- Bootstrap CSS file, change the path accordingly -->
	
<style>';

for ($j=0;$j<$no_col;$j++){


$val=2.5;

if (($no_col==2)&& ($_GET['p']=='1')) { // check if 2 column
	$val=1.2;
}

if ($no_col==3){ // check if 3 column
	if ($_GET['p']=='1') { 
		if ($j<2){
			$val=1.2;
		}
	} else {
	    if ($j>0){
			$val=1.2;
			}
	}
}

if ($no_col==4){ // check if 4 column
   $val=1.2;
} 


$write.='
#'.$name[$j].'{
';
$margintop = ($height[$j] - 90)/$val;
$write.='margin-top:'.round($margintop).'%;
}';
}

$write.='
</style>

</head>
<body> ';

for ($j=0;$j<$no_col;$j++){

$lg='col-lg-12';

if (($no_col==2)&& ($_GET['p']=='1')) { // check if 2 column
	$lg='col-lg-6';
}

if ($no_col==3){ // check if 3 column
	if ($_GET['p']=='1') { 
		if ($j<2){
			$lg='col-lg-6';
		}
	} else {
	    if ($j>0){
			$lg='col-lg-6';
			}
	}
}

if ($no_col==4){ // check if 4 column
   $lg='col-lg-6';
} 

$write.='
<div class="'.$lg.'">
<div class="panel panel-default">
<div class="panel-heading"></div>
	<div class="panel-body">
		<?php echo $result['.$j.'];?>
	</div>
</div>
</div>';
} 
$write.='
</body>';
return $write;
}// End Function
?>
<script src="lib/jquery-linedtextarea.js"></script>
<script>
$(function() {
	$(".lined").linedtextarea(
		{selectedLine: 1}
	);
});

function copypast(id){
	document.getElementById('phpcode').select();
    document.execCommand('copy');
};

</script>

