<?php
$GLOBALS["yJmYDSLqYRjPVkLHRsAk"]=base64_decode("RXJyb3I6IFJlYWQtV3JpdGUgcGVybWlzc2lvbiB0byBmb2xkZXJzIGFuZCBzdWItZm9sZGVycyBvZiBkYXNoYm9hcmRidWlsZGVyIGkuZSBjaG1vZCAtUiA3NzQgZGFzaGJib2FyZGJ1aWxkZXI=");$GLOBALS["srXmZOSrKSnrCofayk"]=base64_decode("ZGF0YS92ZXJzaW9uLnhtbA==");$GLOBALS["zPHSKVJpIbfXHqiVCIsO"]=base64_decode("X1RFWFQ=");$GLOBALS["FLIovxVepvrPFelUHGgg"]=base64_decode("LnBocA==");$GLOBALS["qpdOcjExGVSsvHQlAjHk"]=base64_decode("Li4vbGFuZ3VhZ2Uv");$GLOBALS["BHqisOPCVtcfXsUwXfET"]=base64_decode("dGFrZV90b3VyX2xhbmd1YWdl");$GLOBALS["zOiDoNMOefpEaZNJyDRK"]=base64_decode("bGFuZ3VhZ2VjaGFuZ2U=");$GLOBALS["xtWPYDCsrFrJhduFQcNU"]=base64_decode("bGFuZ3VhZ2U=");$GLOBALS["DjiEFPlvmOmMWHjvSWZz"]=base64_decode("bGFuZm9ybXN1Ym1pdA==");$GLOBALS["KdSmQHHtWgMXDybOLGGB"]=base64_decode("Li4vZGF0YS92ZXJzaW9uLnhtbA==");$GLOBALS["yrxxYDVHrRsXMsevoSgV"]=base64_decode("eWVz");$GLOBALS["VmxhUhdATBNBSCYRbmBA"]=base64_decode("TUVOVQ==");$GLOBALS["PYCXlYVwHgloEIDwtktQ"]=base64_decode("VE9HR0xFX05BVklHQVRJT04=");$GLOBALS["BoHqtCrtcHuLqIuyfjxF"]=base64_decode("c2VsZWN0ZWQ=");$GLOBALS["megMewLdMnADOzrhIkKB"]=base64_decode("YXItc2E=");$GLOBALS["BoHqtCrtcHuLqIuyfjxF"]=base64_decode("c2VsZWN0ZWQ=");$GLOBALS["pNOWlqtsgMyYHPPjCyRZ"]=base64_decode("ZGUtZGU=");$GLOBALS["BoHqtCrtcHuLqIuyfjxF"]=base64_decode("c2VsZWN0ZWQ=");$GLOBALS["RhWCfajegpwGhTZlyezo"]=base64_decode("ZW4tdXM=");$GLOBALS["BoHqtCrtcHuLqIuyfjxF"]=base64_decode("c2VsZWN0ZWQ=");$GLOBALS["scwGeWGeBAriqbCpdYXi"]=base64_decode("ZXMtZXM=");$GLOBALS["BoHqtCrtcHuLqIuyfjxF"]=base64_decode("c2VsZWN0ZWQ=");$GLOBALS["wKtIEFFRLVQDXEFnGeUo"]=base64_decode("ZnItZnI=");$GLOBALS["BoHqtCrtcHuLqIuyfjxF"]=base64_decode("c2VsZWN0ZWQ=");$GLOBALS["gcbpwvtCiRakBFbcNghD"]=base64_decode("aXQtaXQ=");$GLOBALS["BoHqtCrtcHuLqIuyfjxF"]=base64_decode("c2VsZWN0ZWQ=");$GLOBALS["eACrAsIlajbgTpFKOMAl"]=base64_decode("cHQtYnI=");$GLOBALS["QgDRlxWcocZFvfoXIdxu"]=base64_decode("RE9DVU1FTlRBSU9O");$GLOBALS["XzDUDwAkMmJCcRzfsHBb"]=base64_decode("VklERU9fVFVUT1JJQUw=");$GLOBALS["hELNdmwSIlfWnzFSmok"]=base64_decode("VEFLRV9BX1RPVVI=");$GLOBALS["pNAoYRsnGJBDcuQaGGUM"]=base64_decode("U1VQUE9SVA==");$GLOBALS["KIEysRBbbQjimuyTqrbu"]=base64_decode("Rk9SVU0=");$GLOBALS["ZgEGxUbjTVTtFhUHgbo"]=base64_decode("VklTSVRfU0lURQ==");$GLOBALS["xWHOjThJZgoizKdgoMzL"]=base64_decode("OiA=");$GLOBALS["fYHPPlCFsFZzgjElFCfj"]=base64_decode("VkVSU0lPTg==");$GLOBALS["xWHOjThJZgoizKdgoMzL"]=base64_decode("OiA=");$GLOBALS["XTRrSPxChCnFgXVBryOo"]=base64_decode("TElDRU5TRQ==");$GLOBALS["LwqMfEnUWYFEDCUBDCsx"]=base64_decode("RlJFRQ==");$GLOBALS["SnsSSwMKZSYeMFnEirnh"]=base64_decode("");$GLOBALS["GWhAhbtRXkvMVglvWfjd"]=base64_decode("VkFMSURfVElMTA==");$GLOBALS["GxWmtNsoFYuJhvVQhgiv"]=base64_decode("WW1k");$GLOBALS["wsEcqgOUBuvlghluXzeo"]=base64_decode("KzEgbW9udGg=");$GLOBALS["dzJDrZJDGZTkXNRqTdnh"]=base64_decode("KzMgbW9udGg=");$GLOBALS["KdjXufjnryLdoOTQoXXj"]=base64_decode("KzEgeWVhcg==");$GLOBALS["jmyGHJwneoLiWYsPapGx"]=base64_decode("TS1kLVk=");$GLOBALS["FMZwTDttsUAMauIMEZLg"]=base64_decode("QkFTSUM=");$GLOBALS["ngPveNgZZrEDrPCHY"]=base64_decode("UFJP");$GLOBALS["dLDSsINuhdMStMiMqrF"]=base64_decode("UFJFTUlVTQ==");$GLOBALS["gzGekeKbSwHNNogUjfnX"]=base64_decode("WW1k");$GLOBALS["lFboXbBhSCPZiEWiCxgW"]=base64_decode("Y2xhc3M9ImJsaW5rLWJnIg==");$GLOBALS["MunNzmAuGpYqhmdAtRoZ"]=base64_decode("TS1kLVk=");$GLOBALS["UmLiYgMbtShjwKtTNVMo"]=base64_decode("VVBHUkFERV9MSUNFTlNF");
?><?php $xmlinfo=simplexml_load_file($folder.$GLOBALS["srXmZOSrKSnrCofayk"]) or die($GLOBALS["yJmYDSLqYRjPVkLHRsAk"]);;?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html lang="en">
<head>
<title>Dashboard Builder</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<link rel="shortcut icon" href="<?php echo $folder;?>favicon.ico" type="image/x-icon"/>
<link rel="stylesheet" href="<?php echo $folder;?>assets/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo $folder;?>/assets/css/bootstrap-select.min.css">
<link rel="stylesheet" href="<?php echo $folder;?>css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo $folder;?>assets/css/jquery-ui.css">
<link rel="stylesheet" href="<?php echo $folder;?>css/layoutsetting.css"> 
<link rel="stylesheet" href="<?php echo $folder;?>assets/css/color-screen.css"> 


<style>
.side-menu {font-size:11px !important;}
.side-menu input {font-size:11px !important;}
.showhide-filterid select, .side-menu select{
           font-size: 11px !important;
        }
	
.switch-field > label{font-size:11px;}
.switch-field  {margin-left:4px;}
/*if it's not present, don't show loader */

#loading {
  position: fixed;
  display: block;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  text-align: center;
  opacity: 0.7;
  background-color: #fff;
  z-index: 99;
}

#loading-image {
  position: absolute;
  top: 200px;
  left: auto;
  right:auto;
  z-index: 100;

}

.blink-bg{
		color: #fff !important;
		margin:3px;
		padding: 3px;
		display: inline-block;
		border-radius: 2px;
		animation: blinkingBackground 1s infinite;
	}
	@keyframes blinkingBackground{
		60%		{ background-color: #ef0a1a;}
	}
</style>

<script src="<?php echo $folder;?>assets/js/jquery.min.js"></script>
<script src="<?php echo $folder;?>assets/js/jquery-ui.js"></script>
<script src="<?php echo $folder;?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo $folder;?>assets/js/bootstrap-select.min.js"></script>

<script src="<?php echo $folder;?>assets/js/modernizr.js"></script>
<script src="<?php echo $folder;?>assets/js/color-main.js"></script>


<script>
	//paste this code under head tag or in a seperate js file.
	// Wait for window load
	$(window).load(function() {
		// Animate loader off screen
		$(".se-pre-con").fadeOut("slow");;
	});
	

function fdropdownmenu(){
	var x = document.getElementById("dropdown-menu");
  if (window.getComputedStyle(x).display === "none") {
    document.getElementById("dropdown-menu").style.display = "block";
  } else {
	 document.getElementById("dropdown-menu").style.display = "none";
  }
};

function LenSelection() {
document.getElementById("lanform").submit(); 
}
</script>

</head> <?php $xmlfile = $GLOBALS["KdSmQHHtWgMXDybOLGGB"]; $xmlinfo=simplexml_load_file($xmlfile); if (isset($_POST[$GLOBALS["DjiEFPlvmOmMWHjvSWZz"]])) { $xmlinfo->language = $_POST[$GLOBALS["xtWPYDCsrFrJhduFQcNU"]]; $xmlinfo->asXML($xmlfile); } if (isset($_POST[$GLOBALS["zOiDoNMOefpEaZNJyDRK"]])){ if ($_POST[$GLOBALS["zOiDoNMOefpEaZNJyDRK"]]==$GLOBALS["yrxxYDVHrRsXMsevoSgV"]) { $xmlinfo->language = $_POST[$GLOBALS["BHqisOPCVtcfXsUwXfET"]]; $xmlinfo->asXML($xmlfile); } } $xmlinfo->asXML($xmlfile); $languagefile= include($GLOBALS["qpdOcjExGVSsvHQlAjHk"].$xmlinfo->language.$GLOBALS["FLIovxVepvrPFelUHGgg"]); define ($GLOBALS["zPHSKVJpIbfXHqiVCIsO"],$languagefile); ?>


<body>
<script>
  $(window).load(function() {
    $('#loading').hide();
  });
</script>


<div id="loading"><center><img id="loading-image" src="<?php echo $folder;?>assets/img/preloader_1.gif" alt="Loading..." /></center></div>
<nav class="navbar navbar-default navbar-static-top">
    <div class="container-fluid">
		<!-- Brand and toggle get grouped for better mobile display -->
		<div class="navbar-header">
					
			
			<button type="button" class="navbar-toggle navbar-toggle-sidebar collapsed">
		 <?php echo _TEXT[$GLOBALS["VmxhUhdATBNBSCYRbmBA"]];?>
			</button>
			<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
				<span class="sr-only"><?php echo _TEXT[$GLOBALS["PYCXlYVwHgloEIDwtktQ"]];?></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" href="#" style="margin-top:-20px;">
				<img src="<?php echo $folder;?>assets/img/dashboardbuilder_logo.png"/>
			</a>
		</div>

		<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">  
	
			<ul class="nav navbar-nav navbar-right">
				<li class="dropdown ">
					<a href="javascript:void(0);"  class="dropdown-toggle" onclick="fdropdownmenu();" data-toggle="dropdown" role="button" aria-expanded="false">
						<span class="fa fa-question-circle" style="font-size:2em; " ></span>
						<span class="caret"></span>
						</a>
						<ul class="dropdown-menu" id="dropdown-menu" role="menu" style="padding-top:15px;">
						
						<form name="lanform" id="lanform" action="" enctype="multipart/form-data" method="post" >
						<span style="text-align:left;margin-left:20px;">
						 <span class="fa fa-globe" style="font-size:1.3em;" ></span>
						 <select  style="text-align:left;" name="language" value="en-us" onchange="LenSelection();" >
							<option value="ar-sa" <?php if ($xmlinfo->language==$GLOBALS["megMewLdMnADOzrhIkKB"]) {echo $GLOBALS["BoHqtCrtcHuLqIuyfjxF"];}?>>عربى</option>
							<option value="de-de" <?php if ($xmlinfo->language==$GLOBALS["pNOWlqtsgMyYHPPjCyRZ"]) {echo $GLOBALS["BoHqtCrtcHuLqIuyfjxF"];}?>>Deutsche</option>
							<option value="en-us" <?php if ($xmlinfo->language==$GLOBALS["RhWCfajegpwGhTZlyezo"]) {echo $GLOBALS["BoHqtCrtcHuLqIuyfjxF"];}?> >English</option>
							<option value="es-es" <?php if ($xmlinfo->language==$GLOBALS["scwGeWGeBAriqbCpdYXi"]) {echo $GLOBALS["BoHqtCrtcHuLqIuyfjxF"];}?>>Español</option>
							<option value="fr-fr" <?php if ($xmlinfo->language==$GLOBALS["wKtIEFFRLVQDXEFnGeUo"]) {echo $GLOBALS["BoHqtCrtcHuLqIuyfjxF"];}?>>Français</option>
							<option value="it-it" <?php if ($xmlinfo->language==$GLOBALS["gcbpwvtCiRakBFbcNghD"]) {echo $GLOBALS["BoHqtCrtcHuLqIuyfjxF"];}?>>Italiano</option>
							<option value="pt-br" <?php if ($xmlinfo->language==$GLOBALS["eACrAsIlajbgTpFKOMAl"]) {echo $GLOBALS["BoHqtCrtcHuLqIuyfjxF"];}?>>Português</option>
						 </select>
						 </span>
						 <input type="hidden" name="lanformsubmit" value="true" />
						 </form>
						
							<li><a href="https://dashboardbuilder.net/documentation" target="_blank"><?php echo _TEXT[$GLOBALS["QgDRlxWcocZFvfoXIdxu"]];?></a></li>
							<li><a href="javascript:void(0);" onclick="changeVideo('v7qde35K6tM')" ><?php echo _TEXT[$GLOBALS["XzDUDwAkMmJCcRzfsHBb"]];?></a></li>
							<li><a href="javascript:void(0);" onclick="$('#takeatour').modal({backdrop: 'static', keyboard: false});" ><?php echo _TEXT[$GLOBALS["hELNdmwSIlfWnzFSmok"]];?></a></li>
							
							<li><a href="https://dashboardbuilder.net/support" target="_blank"><?php echo _TEXT[$GLOBALS["pNAoYRsnGJBDcuQaGGUM"]];?></a></li>
							<li><a href="https://dashboardbuilder.net/forum" target="_blank"><?php echo _TEXT[$GLOBALS["KIEysRBbbQjimuyTqrbu"]];?></a></li>
							<li><a href="https://dashboardbuilder.net" target="_blank"><?php echo _TEXT[$GLOBALS["ZgEGxUbjTVTtFhUHgbo"]];?></a></li>
							<li><a href="javascript:void(0);" onclick="phpinfo();">PHPinfo()</a></li>
							<li class="divider"></li>
							<li><a href="javascript:void(0);" style="pointer-events: none;"> <?php echo _TEXT[$GLOBALS["fYHPPlCFsFZzgjElFCfj"]].$GLOBALS["xWHOjThJZgoizKdgoMzL"].$xmlinfo->version; ?></a></li>
							<li><a href="javascript:void(0);" style="pointer-events: none;"> <?php echo _TEXT[$GLOBALS["XTRrSPxChCnFgXVBryOo"]].$GLOBALS["xWHOjThJZgoizKdgoMzL"].$xmlinfo->type; ?></a></li>
							
						 <?php $upgrade =$GLOBALS["SnsSSwMKZSYeMFnEirnh"]; if (!($xmlinfo->type==$GLOBALS["LwqMfEnUWYFEDCUBDCsx"]) ) {?>
							<li><a href="#" style="pointer-events: none;"><?php echo _TEXT[$GLOBALS["GWhAhbtRXkvMVglvWfjd"]];?>: 
						 <?php if (empty($xmlinfo->date)) { $xmlinfo->date=date($GLOBALS["gzGekeKbSwHNNogUjfnX"]); if ($xmlinfo->type==$GLOBALS["dLDSsINuhdMStMiMqrF"]) { $expirydate = date($GLOBALS["jmyGHJwneoLiWYsPapGx"],strtotime($GLOBALS["KdjXufjnryLdoOTQoXXj"],strtotime($xmlinfo->date))); } elseif ($xmlinfo->type==$GLOBALS["ngPveNgZZrEDrPCHY"]) { $expirydate = date($GLOBALS["jmyGHJwneoLiWYsPapGx"],strtotime($GLOBALS["dzJDrZJDGZTkXNRqTdnh"],strtotime($xmlinfo->date))); } elseif ($xmlinfo->type==$GLOBALS["FMZwTDttsUAMauIMEZLg"]) { $expirydate = date($GLOBALS["jmyGHJwneoLiWYsPapGx"],strtotime($GLOBALS["wsEcqgOUBuvlghluXzeo"],strtotime($xmlinfo->date))); } $xmlinfo->date=date($GLOBALS["GxWmtNsoFYuJhvVQhgiv"],strtotime($expirydate)); $xmlinfo->asXML($xmlfile); } else { $expirydate = date($GLOBALS["jmyGHJwneoLiWYsPapGx"],strtotime($xmlinfo->date)); } echo $expirydate; ?></a></li>
						 <?php $date1 = strtotime(date($GLOBALS["MunNzmAuGpYqhmdAtRoZ"])); $diff = round((strtotime($expirydate) - $date1)/86400); if ($diff < 1) { $upgrade = $GLOBALS["lFboXbBhSCPZiEWiCxgW"]; } }?>

							<li><a href="https://dashboardbuilder.net/license-upgrade" target="_blank" <?php echo $upgrade;?>>
						 <?php echo _TEXT[$GLOBALS["UmLiYgMbtShjwKtTNVMo"]];?>
							</a></li>
						</ul>
					</li>
				</ul>
			</div><!-- /.navbar-collapse -->
		</div><!-- /.container-fluid -->
	</nav> 
<script>
function phpinfo() {
document.getElementById("details").style.display = "none"; 
document.getElementById("details").innerHTML='<object type="text/html" data="phpinfo.php" style="width: 100%; height: 500px; min-height:300px;"></object>';
document.getElementById("details").style.display = "block"; 
document.getElementById("dropdown-menu").style.display = "none";

document.getElementById("close_preview").style.display = "inline-block";

document.getElementById("preview").style.display = "none"; 
document.getElementById("addpanelid").style.display = "none";
document.getElementById("addpanelid").style.display = "none";
document.getElementById("file-generate").style.display = "none";
document.getElementById("file-open").style.display = "none";
document.getElementById("file-new").style.display = "none";
document.getElementById("file-save").style.display = "none";
document.getElementById("file-share").style.display = "none";
document.getElementById("addfilterid").style.display = "none";

}
</script>