<?php
$GLOBALS["tFnSCeRVNdrOhqsaZz"]=base64_decode("TG9jYXRpb246IA==");$GLOBALS["LPyaylUxVVfmVUOEbBtQ"]=base64_decode("c2F2ZQ==");$GLOBALS["FQqsRdxUZSaCuTVwkpsp"]=base64_decode("dGFzaw==");$GLOBALS["KdSmQHHtWgMXDybOLGGB"]=base64_decode("Li4vZGF0YS92ZXJzaW9uLnhtbA==");$GLOBALS["kVGZLEGuRFtyiVBVBpE"]=base64_decode("Y29s");$GLOBALS["QggfylPeyGMJVYaMRycd"]=base64_decode("UkVRVUVTVF9VUkk=");$GLOBALS["NtdsMpHgWUbzWljfFtkE"]=base64_decode("SFRUUF9SRUZFUkVS");$GLOBALS["haixgOStSXLghjfsRjYn"]=base64_decode("dGFzaw==");$GLOBALS["SnsSSwMKZSYeMFnEirnh"]=base64_decode("");$GLOBALS["uxDHiianpzbwOKuWXiZ"]=base64_decode("Li4=");$GLOBALS["pVzlirkpbVzCAYyFDlBn"]=base64_decode("REFUQV9TT1VSQ0VfU0VUVElORw==");$GLOBALS["pVzlirkpbVzCAYyFDlBn"]=base64_decode("REFUQV9TT1VSQ0VfU0VUVElORw==");$GLOBALS["KVdvhJpQsmNzDpEktnig"]=base64_decode("ZGF0YS9kYXRhLnhtbA==");$GLOBALS["kVGZLEGuRFtyiVBVBpE"]=base64_decode("Y29s");$GLOBALS["NFHFxZiEQXOmAEpkqzsw"]=base64_decode("dXBsb2Fk");$GLOBALS["SHlRCNLzGtCGyHhhetLl"]=base64_decode("MQ==");$GLOBALS["nhuNXiJuwAFpIscFNrVf"]=base64_decode("aHR0cHM6");$GLOBALS["joqsMvTyqKCbnHhtTAwQ"]=base64_decode("Y2hlY2tlZA==");$GLOBALS["SnsSSwMKZSYeMFnEirnh"]=base64_decode("");$GLOBALS["mNprkDRbCxOazMzvSsJg"]=base64_decode("YWN0aXZl");$GLOBALS["ZIbJHadcBqkVtwmxygNH"]=base64_decode("REFUQUJBU0U=");$GLOBALS["DJyPKikgGCDrhIndRmmV"]=base64_decode("RklMRQ==");$GLOBALS["ZIbJHadcBqkVtwmxygNH"]=base64_decode("REFUQUJBU0U=");$GLOBALS["tugkmwKQmrdyfghQnRJj"]=base64_decode("");$GLOBALS["IKqmWzijRTgonLleHqBw"]=base64_decode("bXlzcWw=");$GLOBALS["vHgqefPMUJbtZjbPIZVh"]=base64_decode("c3FsaXRl");$GLOBALS["YEMYzLFpdvVCqlmCKKlF"]=base64_decode("b2RiYw==");$GLOBALS["vHgqefPMUJbtZjbPIZVh"]=base64_decode("c3FsaXRl");$GLOBALS["bRMfIAsMBLFLECMGJLRJ"]=base64_decode("SE9TVA==");$GLOBALS["vHgqefPMUJbtZjbPIZVh"]=base64_decode("c3FsaXRl");$GLOBALS["JbKcVOfBaKAogQlrrSU"]=base64_decode("RU5URVJfSE9TVF9OQU1F");$GLOBALS["vHgqefPMUJbtZjbPIZVh"]=base64_decode("c3FsaXRl");$GLOBALS["UgoZkonkEmAUBJodbbVo"]=base64_decode("VVNFUg==");$GLOBALS["vHgqefPMUJbtZjbPIZVh"]=base64_decode("c3FsaXRl");$GLOBALS["gKwTPaaAaYkDujWVcNVh"]=base64_decode("RU5URVJfVVNFUl9OQU1F");$GLOBALS["vHgqefPMUJbtZjbPIZVh"]=base64_decode("c3FsaXRl");$GLOBALS["xSdAWsSNTMfMQIhfBXAs"]=base64_decode("UEFTU1dPUkQ=");$GLOBALS["utwrZcrQVelhtmpVIzbv"]=base64_decode("REJfTkFNRQ==");$GLOBALS["YcquONcFzRvubnGJzUfi"]=base64_decode("RFNfTkFNRQ==");$GLOBALS["PDjLokAxPrqTOVmeCGct"]=base64_decode("VFlQRV9ZT1VSX0RBVEFCQVNFX05BTUU=");$GLOBALS["hLQZZQbYoLVVHuGcqiA"]=base64_decode("RU5URVJfREJfTkFNRQ==");$GLOBALS["XYTFvxAXvYkcKHBfwclI"]=base64_decode("U1NMX0VOQUJMRUQ=");$GLOBALS["mfIwKKSrnTzkbpLxPTYH"]=base64_decode("Y2hlY2tlZA==");$GLOBALS["LbWtvOtAgvsirpohWdSc"]=base64_decode("b24=");$GLOBALS["mDBaYRUxLSMzfxTMWTRZ"]=base64_decode("VVBMT0FEX0ZJTEU=");$GLOBALS["YluBnwWemDEeROGCAAnj"]=base64_decode("U0VMRUNUX1hMU19DU1Y=");$GLOBALS["YluBnwWemDEeROGCAAnj"]=base64_decode("U0VMRUNUX1hMU19DU1Y=");$GLOBALS["MGGUjRNQDeFfmMmFysCe"]=base64_decode("PC9vcHRpb24+");$GLOBALS["tAGGrOKxpRduOPmQmnlr"]=base64_decode("Ij4=");$GLOBALS["TMWgYWGklnGOmOncZDzO"]=base64_decode("PG9wdGlvbiB2YWx1ZT0i");$GLOBALS["GgxrebkTtGAJarKlfDjG"]=base64_decode("L1xcLw==");$GLOBALS["tugkmwKQmrdyfghQnRJj"]=base64_decode("");$GLOBALS["DOEIONFcktnoVHkFuIdv"]=base64_decode("Ly4uLmRhdGEv");$GLOBALS["yOtSkPOaqEwpDfBnwpSw"]=base64_decode("Ki57Y3N2LHhscyx4bHN4fQ==");$GLOBALS["TkTImXpgWecqAfMQVEHf"]=base64_decode("ZGF0YQ==");$GLOBALS["xqggMhWPiQnZOGUOUyLc"]=base64_decode("VkFMSURfVVJM");$GLOBALS["xqggMhWPiQnZOGUOUyLc"]=base64_decode("VkFMSURfVVJM");$GLOBALS["UftEBHifVSdqinnDGZmn"]=base64_decode("Q0FOQ0VM");$GLOBALS["yzqOBvCFRlJNoExEIaJv"]=base64_decode("U0FWRV9DSEFOR0VT");$GLOBALS["mcnbxJZabxmxvnNJtAA"]=base64_decode("MTIzNDU2Nzg5MTAxMTEyMQ==");$GLOBALS["GXlNvhDYmCGsWfqLMzpP"]=base64_decode("ZmlsZW5hbWU=");$GLOBALS["zgfjWEwNNayMZBRdHrDM"]=base64_decode("anNvbl91cmw=");$GLOBALS["CWkSJAwkFucZtXTBVUwH"]=base64_decode("anNvbg==");$GLOBALS["rHfBnDikaoIpLTqSXWRS"]=base64_decode("Z29vZ2xlX3VybA==");$GLOBALS["mFGCSnEFevFdfjEaRs"]=base64_decode("Y2xvdWQ=");$GLOBALS["qQmtIhpEGLBEGZtrwoxI"]=base64_decode("cGNfY2xvdWQ=");$GLOBALS["NFHFxZiEQXOmAEpkqzsw"]=base64_decode("dXBsb2Fk");$GLOBALS["YEMYzLFpdvVCqlmCKKlF"]=base64_decode("b2RiYw==");$GLOBALS["vHgqefPMUJbtZjbPIZVh"]=base64_decode("c3FsaXRl");$GLOBALS["aaVSngfyKHLQgxZvwrY"]=base64_decode("MA==");$GLOBALS["JnsZplZErOzGpBDSQcnM"]=base64_decode("b2Np");$GLOBALS["SHlRCNLzGtCGyHhhetLl"]=base64_decode("MQ==");$GLOBALS["JmLHqpYcNjsSfaXglppE"]=base64_decode("RGF0YWJhc2U=");$GLOBALS["ZZUqLRTtOPEhDvABGXxH"]=base64_decode("U2VydmVy");$GLOBALS["oLnHtFxoAIZrAqrrMoBQ"]=base64_decode("c3Fsc3J2");$GLOBALS["ZOlgKexAMiVzUOeICAxy"]=base64_decode("Ow==");$GLOBALS["QkFZTTIeBvQdgwxtrjID"]=base64_decode("cG9ydD0=");$GLOBALS["DWmsYJsvcfBZEyObOnZU"]=base64_decode("aHR0cHM6Ly8=");$GLOBALS["teeMKStMReeaqAoSOCuJ"]=base64_decode("ZGJuYW1l");$GLOBALS["qhJymdWpyVJoFTtbyogs"]=base64_decode("cGFzc3dvcmQ=");$GLOBALS["HCMlNHVSDHWnXZLjdesa"]=base64_decode("dXNlcg==");$GLOBALS["lmoCHwPemluShUKlVVrD"]=base64_decode("c3Ns");$GLOBALS["tugkmwKQmrdyfghQnRJj"]=base64_decode("");$GLOBALS["ZoqDfOutZhXDmAWQySwT"]=base64_decode("aG9zdA==");$GLOBALS["yCCELdQbYTAhYCLkUGg"]=base64_decode("cmRibXM=");$GLOBALS["WmndJmrTJdHCBhCnRXMB"]=base64_decode("QURhdGFiYXNl");$GLOBALS["OqmFMVIWsbjbxDPrA"]=base64_decode("c291cmNl");$GLOBALS["oCwUFOvhDrAOfWyazNDH"]=base64_decode("Li4vZGF0YS9kYXRhLnhtbA==");$GLOBALS["JiSjXGwvCpsuVDsfnjcl"]=base64_decode("TGs1VXozc2x4M0JyQWdoUzFhYVc1QVlnV1pSVjB0SVg1ZUkweVBjaEZ6ND0=");$GLOBALS["rTpZDGFNjBGeyajrbzA"]=base64_decode("QUVTLTEyOC1DQkM=");$GLOBALS["VsESaojOTXdmcfrFhBgY"]=base64_decode("WWVz");$GLOBALS["PGnDVWIKgIUmFrZyuhhU"]=base64_decode("dG1wX25hbWU=");$GLOBALS["zIEKBWYDAoDgpOLxPwTc"]=base64_decode("Li4vZGF0YS8=");$GLOBALS["XckkIahjVOedVNldUNrH"]=base64_decode("bmFtZQ==");$GLOBALS["BJfucULQDYxFBbgIdOQ"]=base64_decode("ZmlsZVRvVXBsb2Fk");$GLOBALS["cEnkzazMhFtVVgVOlaQm"]=base64_decode("OyA=");$GLOBALS["yKJYEAspYGWeQuaPqCrJ"]=base64_decode("Ow==");$GLOBALS["lhysjbAVbLipeHcOM"]=base64_decode("PQ==");$GLOBALS["JYNtVdTfHlgJkTOjMvtL"]=base64_decode("Og==");$GLOBALS["JsPuQXopAGHsqRwURiUS"]=base64_decode("Lw==");$GLOBALS["SnsSSwMKZSYeMFnEirnh"]=base64_decode("");$GLOBALS["hLQZZQbYoLVVHuGcqiA"]=base64_decode("RU5URVJfREJfTkFNRQ==");$GLOBALS["hLQZZQbYoLVVHuGcqiA"]=base64_decode("RU5URVJfREJfTkFNRQ==");$GLOBALS["NFHFxZiEQXOmAEpkqzsw"]=base64_decode("dXBsb2Fk");$GLOBALS["YluBnwWemDEeROGCAAnj"]=base64_decode("U0VMRUNUX1hMU19DU1Y=");$GLOBALS["xqggMhWPiQnZOGUOUyLc"]=base64_decode("VkFMSURfVVJM");$GLOBALS["xqggMhWPiQnZOGUOUyLc"]=base64_decode("VkFMSURfVVJM");
?><?php $url = $_SERVER[$GLOBALS["QggfylPeyGMJVYaMRycd"]]; $folder =$GLOBALS["uxDHiianpzbwOKuWXiZ"].DIRECTORY_SEPARATOR; $google_url = $GLOBALS["SnsSSwMKZSYeMFnEirnh"]; $json=$GLOBALS["SnsSSwMKZSYeMFnEirnh"]; $json_url = $GLOBALS["SnsSSwMKZSYeMFnEirnh"]; $saved_url = $GLOBALS["SnsSSwMKZSYeMFnEirnh"]; $col = (int) $_REQUEST[$GLOBALS["kVGZLEGuRFtyiVBVBpE"]]; $xmlversion=simplexml_load_file($GLOBALS["KdSmQHHtWgMXDybOLGGB"]); $legacy = $xmlversion->legacy; if (isset($_GET[$GLOBALS["FQqsRdxUZSaCuTVwkpsp"]])) { if ($_GET[$GLOBALS["haixgOStSXLghjfsRjYn"]]==$GLOBALS["LPyaylUxVVfmVUOEbBtQ"]){ savedataDB($col); header($GLOBALS["tFnSCeRVNdrOhqsaZz"] . $_SERVER[$GLOBALS["NtdsMpHgWUbzWljfFtkE"]] ); } } ?>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<title><?php echo _TEXT[$GLOBALS["pVzlirkpbVzCAYyFDlBn"]];?></title> 
<style>
#ds-name {display:none;}
</style>
 

 <!-- Modal -->
 
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true" onclick="javascript:window.location.href = window.location.href;">&times;</button>
                 <h4 class="modal-title"><?php echo _TEXT[$GLOBALS["pVzlirkpbVzCAYyFDlBn"]];?></h4>
            </div>			<!-- /modal-header -->
		 <?php $xmlDoc=simplexml_load_file($folder.$GLOBALS["KVdvhJpQsmNzDpEktnig"]); if (!isset ($xmlDoc->col[$col]->rdbms)) { $xmlDoc->col[$col]->source = $xmlDoc->col[0]->source; $xmlDoc->col[$col]->rdbms = $xmlDoc->col[0]->rdbms; $xmlDoc->col[$col]->servername = $xmlDoc->col[0]->servername ; $xmlDoc->col[$col]->ssl = $xmlDoc->col[0]->ssl; $xmlDoc->col[$col]->username = $xmlDoc->col[0]->username ; $xmlDoc->col[$col]->password = $xmlDoc->col[0]->password; $xmlDoc->col[$col]->dbname = $xmlDoc->col[0]->dbname; $xmlDoc->col[$col]->dbconnected = $xmlDoc->col[0]->dbconnected ; $xmlDoc->col[$col]->file = $xmlDoc->col[0]->file; $xmlDoc->col[$col]->json = $xmlDoc->col[0]->json; $xmlDoc->asXML($folder.$GLOBALS["KVdvhJpQsmNzDpEktnig"]); } $rdbms = $xmlDoc->col[$col]->rdbms; $title = $xmlDoc->col[$col]->title; ?>

			<form id="dbsetting" class="form-horizontal" enctype="multipart/form-data" action="dbsetting2.php?task=save&layout=1&col=<?php echo $_POST[$GLOBALS["kVGZLEGuRFtyiVBVBpE"]];?>" method="post" onsubmit="return validateForm();">
			<fieldset>
			 </br>
			
			<div class="modal-body">
			
			<!-- Tab Panel starts -->
			<ul class="nav nav-tabs">
		 <?php $dbTabActive = $GLOBALS["mNprkDRbCxOazMzvSsJg"]; $xlTabActive = $GLOBALS["SnsSSwMKZSYeMFnEirnh"]; if ($xmlDoc->col[$col]->dbconnected== $GLOBALS["SHlRCNLzGtCGyHhhetLl"]){ $dbTabActive = $GLOBALS["mNprkDRbCxOazMzvSsJg"]; $xlTabActive = $GLOBALS["SnsSSwMKZSYeMFnEirnh"]; } if ($xmlDoc->col[$col]->source== $GLOBALS["NFHFxZiEQXOmAEpkqzsw"]){ if (!empty ($xmlDoc->col[$col]->json)) { $json = $GLOBALS["joqsMvTyqKCbnHhtTAwQ"]; $google_url = $GLOBALS["SnsSSwMKZSYeMFnEirnh"]; $dbTabActive = $GLOBALS["SnsSSwMKZSYeMFnEirnh"]; $xlTabActive = $GLOBALS["mNprkDRbCxOazMzvSsJg"]; $json_url = $xmlDoc->col[$col]->json; $saved_url=$GLOBALS["SnsSSwMKZSYeMFnEirnh"]; } else { if (substr($xmlDoc->col[$col]->file,0,6)==$GLOBALS["nhuNXiJuwAFpIscFNrVf"] ) { $google_url = $GLOBALS["joqsMvTyqKCbnHhtTAwQ"]; $json = $GLOBALS["SnsSSwMKZSYeMFnEirnh"]; $dbTabActive = $GLOBALS["SnsSSwMKZSYeMFnEirnh"]; $xlTabActive = $GLOBALS["mNprkDRbCxOazMzvSsJg"]; $saved_url = $xmlDoc->col[$col]->file; $json_url=$GLOBALS["SnsSSwMKZSYeMFnEirnh"]; } else { if (file_exists($xmlDoc->col[$col]->file)) { $dbTabActive = $GLOBALS["SnsSSwMKZSYeMFnEirnh"]; $xlTabActive = $GLOBALS["mNprkDRbCxOazMzvSsJg"]; } } } } ?>
			  <li class="<?php echo $dbTabActive;?>"><a data-toggle="tab" href="#home" onclick="tabvalue('ADatabase');">&nbsp;&nbsp;&nbsp;&nbsp; <?php echo _TEXT[$GLOBALS["ZIbJHadcBqkVtwmxygNH"]];?> &nbsp;&nbsp;&nbsp;&nbsp;</a></li>
			  <li class="<?php echo $xlTabActive;?>"><a data-toggle="tab" id="xltabid" href="#menu1" onclick="tabvalue('upload');">   <?php echo _TEXT[$GLOBALS["DJyPKikgGCDrhIndRmmV"]];?></a></li>
			  <input type="hidden" id="source" name="source" value="ADatabase" />
			</ul>

			<div class="tab-content">
			<!-- Tab for Data Source -->
			  <div id="home" class="tab-pane fade in <?php echo $dbTabActive;?>">

			  		<p>&nbsp;</p>
					<div id="Database" >
					<!-- Database connection -->
						<label  class="col-sm-3 control-label"><?php echo _TEXT[$GLOBALS["ZIbJHadcBqkVtwmxygNH"]];?>:</label>
						  <div class="col-sm-8" >
						  <select class="form-control" id="rdbms" name="rdbms" value="<?php echo $rdbms;?>" onchange="DBSelection()">
							<option value="mysql" <?php if (($rdbms==$GLOBALS["IKqmWzijRTgonLleHqBw"]) || ($rdbms==$GLOBALS["tugkmwKQmrdyfghQnRJj"])){?> selected <?php }?>>MySQL</option>
							<option value="sqlite" <?php if ($rdbms==$GLOBALS["vHgqefPMUJbtZjbPIZVh"]){?> selected <?php }?>>SQLite</option>
						  </select>
						  </div>
						  
						
						<div id="hostID" <?php if (($rdbms==$GLOBALS["vHgqefPMUJbtZjbPIZVh"]) || ($rdbms==$GLOBALS["YEMYzLFpdvVCqlmCKKlF"])){?> style="display:none;"<?php }?>>  
						<br/><p>&nbsp;</p>
					  	<label class="col-sm-3 control-label"><?php echo _TEXT[$GLOBALS["bRMfIAsMBLFLECMGJLRJ"]];?>:</label> 
						<div class="col-sm-8">
						   <input type="text" class="form-control" id="host" name="host" value="<?php echo $xmlDoc->col[$col]->servername;?>" placeholder="localhost" size="50" <?php if (!($rdbms==$GLOBALS["vHgqefPMUJbtZjbPIZVh"])){?> required oninvalid="this.setCustomValidity('<?php echo _TEXT[$GLOBALS["JbKcVOfBaKAogQlrrSU"]];?>')" oninput="setCustomValidity('')" <?php }?>/>    
						</div>
						</div>
						
						
						<div id="userID" <?php if ($rdbms==$GLOBALS["vHgqefPMUJbtZjbPIZVh"]){?> style="display:none;"<?php }?>>
						<br/><p>&nbsp;</p>
						<label class="col-sm-3 control-label"><?php echo _TEXT[$GLOBALS["UgoZkonkEmAUBJodbbVo"]];?>:</label> 
						<div class="col-sm-8">
						   <input type="text" class="form-control" id="user" name="user" value="<?php echo $xmlDoc->col[$col]->username;?>" placeholder="root" size="50" <?php if (!($rdbms==$GLOBALS["vHgqefPMUJbtZjbPIZVh"])){?> required oninvalid="this.setCustomValidity('<?php echo _TEXT[$GLOBALS["gKwTPaaAaYkDujWVcNVh"]];?>')" oninput="setCustomValidity('')"  <?php }?>/>    
						</div>
						</div>
						
						<div id="passwordID" <?php if ($rdbms==$GLOBALS["vHgqefPMUJbtZjbPIZVh"]){?> style="display:none;"<?php }?>>
						<br/><p>&nbsp;</p>
						<label class="col-sm-3 control-label"><?php echo _TEXT[$GLOBALS["xSdAWsSNTMfMQIhfBXAs"]];?>:</label> 
						<div class="col-sm-8">
						   <input type="password" class="form-control" id="password" name="password" value="<?php echo passdescryption($xmlDoc->col[$col]->password);?>" size="50"/>    
						</div>
						</div>
						
						<br/><p>&nbsp;</p>
						
						<label class="col-sm-3 control-label" id="db-name"><?php echo _TEXT[$GLOBALS["utwrZcrQVelhtmpVIzbv"]];?>:</label> 
						<label class="col-sm-3 control-label" id="ds-name"><?php echo _TEXT[$GLOBALS["YcquONcFzRvubnGJzUfi"]];?>:</label> 
						<div class="col-sm-8">
						   <input type="text" id="dbname" class="form-control" name="dbname" value="<?php echo $xmlDoc->col[$col]->dbname;?>" placeholder="<?php echo _TEXT[$GLOBALS["PDjLokAxPrqTOVmeCGct"]];?>" size="50" required oninvalid="this.setCustomValidity('<?php echo _TEXT[$GLOBALS["hLQZZQbYoLVVHuGcqiA"]];?>')" oninput="setCustomValidity('')" />    
						</div>
						<br/><p>&nbsp;</p>
						
						<label class="col-sm-3 control-label"><?php echo _TEXT[$GLOBALS["XYTFvxAXvYkcKHBfwclI"]];?>:</label> 
						<div class="col-sm-2">
						   <input type="checkbox" id="ssl" name="ssl" <?php if($xmlDoc->col[$col]->ssl==$GLOBALS["LbWtvOtAgvsirpohWdSc"]){ echo $GLOBALS["mfIwKKSrnTzkbpLxPTYH"];}?> />   
						</div>
						<br/><p>&nbsp;</p>

					</div>
					
			  </div>
			<!-- Tab Data Source end -->
	
			<!-- Tab for Properties -->  
			  <div id="menu1" class="tab-pane fade in <?php echo $xlTabActive;?>">
				<div class="col-md-12">
				<br/>         
				
				<input type="radio" name="pc_cloud" value="pc" checked id="pc">
				<label> <?php echo _TEXT[$GLOBALS["mDBaYRUxLSMzfxTMWTRZ"]];?></label>
						 <?php if($xlTabActive) {?>
								<div class="label label-success"><?php echo basename($xmlDoc->col[$col]->file);?></div>
							  <?php } ?>
							  
							  <div class="form-group files">

								<input type="file" name="fileToUpload" id="fileToUpload" class="form-control"  title="<?php echo _TEXT[$GLOBALS["YluBnwWemDEeROGCAAnj"]];?>" oninvalid="this.setCustomValidity('<?php echo _TEXT[$GLOBALS["YluBnwWemDEeROGCAAnj"]];?>')" oninput="setCustomValidity('')"
								value ="<?php if (file_exists($xmlDoc->col[$col]->file)) {echo $xmlDoc->col[$col]->file;}?>" lang="de-de"/>								
								
								<div class="col-md-8 col-lg-8 col-sm-8">
									<select  id="fileselect" name="filename" class="form-control col-sm-offset-2" size="6" onclick="fileselect_f();">
									   <?php $search = $folder. $GLOBALS["TkTImXpgWecqAfMQVEHf"].DIRECTORY_SEPARATOR.$GLOBALS["yOtSkPOaqEwpDfBnwpSw"]; $patterns = array(); $replacements = array(); foreach (glob($search, GLOB_BRACE) as $filename) { $filenamevalue = $filename; $patterns[0] = $GLOBALS["DOEIONFcktnoVHkFuIdv"]; $replacements[0] = $GLOBALS["tugkmwKQmrdyfghQnRJj"]; $patterns[2] = $GLOBALS["GgxrebkTtGAJarKlfDjG"]; $replacements[2] = $GLOBALS["tugkmwKQmrdyfghQnRJj"]; $filename= preg_replace($patterns, $replacements, $filename); echo $GLOBALS["TMWgYWGklnGOmOncZDzO"]. $filenamevalue.$GLOBALS["tAGGrOKxpRduOPmQmnlr"]. $filename .$GLOBALS["MGGUjRNQDeFfmMmFysCe"]; } ?>    
										</select>
										<br/>
									</div>								
								
								
							  </div>           
						    
				</div>
				
				<div class="col-md-12"> 
				<input type="radio" name="pc_cloud" value="cloud" id="cloud" <?php echo $google_url;?> onchange="google_url_f();"><label>&nbsp;Google Drive</label>&nbsp;
				<input type="url" name="google_url" id="google_url"
				   placeholder="https://docs.google.com/spreadsheets.."
				   pattern="https://.*" size="55"
				    onfocus="google_url_f();"
					oninvalid="this.setCustomValidity('<?php echo _TEXT[$GLOBALS["xqggMhWPiQnZOGUOUyLc"]];?>')" oninput="setCustomValidity('')"
					value ="<?php echo $saved_url;?>"
				   >
				   <p><br/></p>
				</div>
				
				
				<div class="col-md-12"> 
				<input type="radio" name="pc_cloud" value="json" id="json" <?php echo $json;?> onchange="json_url_f();"><label>&nbsp;JSON</label>&nbsp;
				<input type="url" name="json_url" id="json_url"
				   placeholder="https://dataondemand.nasdaq.com/api/..."
				    pattern="http.*" size="55"
				    onfocus="json_url_f();"
					oninvalid="this.setCustomValidity('<?php echo _TEXT[$GLOBALS["xqggMhWPiQnZOGUOUyLc"]];?>')" oninput="setCustomValidity('')"
					value ="<?php echo $json_url;?>"
				   >
				   <p><br/></p>
				</div>
				
			  </div>
			  <!-- Tab Properties Ends -->
			  
			  
			</div>
			<!-- Tab Panel Ends -->

			<div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" onclick="javascript:window.location.href = window.location.href;"><?php echo _TEXT[$GLOBALS["UftEBHifVSdqinnDGZmn"]];?></button>
                <button type="submit" class="btn btn-primary"><?php echo _TEXT[$GLOBALS["yzqOBvCFRlJNoExEIaJv"]];?></button>
            </div>
			</fieldset>
			</form>
			</div>			<!-- /modal-body -->

 <?php function savedataDB($col) { $xmlfile = $GLOBALS["oCwUFOvhDrAOfWyazNDH"]; $xmlDoc=simplexml_load_file($xmlfile); $xmlDoc->col[$col]->source = $_POST[$GLOBALS["OqmFMVIWsbjbxDPrA"]]; if ($_POST[$GLOBALS["OqmFMVIWsbjbxDPrA"]]==$GLOBALS["WmndJmrTJdHCBhCnRXMB"]){ $xmlDoc->col[$col]->rdbms = $_POST[$GLOBALS["yCCELdQbYTAhYCLkUGg"]]; } if (!empty($_POST[$GLOBALS["ZoqDfOutZhXDmAWQySwT"]])){ $xmlDoc->col[$col]->servername = $_POST[$GLOBALS["ZoqDfOutZhXDmAWQySwT"]]; } $xmlDoc->col[$col]->ssl = $GLOBALS["tugkmwKQmrdyfghQnRJj"]; if (!empty($_POST[$GLOBALS["lmoCHwPemluShUKlVVrD"]])){ $xmlDoc->col[$col]->ssl = $_POST[$GLOBALS["lmoCHwPemluShUKlVVrD"]]; } if (!empty($_POST[$GLOBALS["HCMlNHVSDHWnXZLjdesa"]])){ $xmlDoc->col[$col]->username = $_POST[$GLOBALS["HCMlNHVSDHWnXZLjdesa"]]; } $xmlDoc->col[$col]->password = passencryption($_POST[$GLOBALS["qhJymdWpyVJoFTtbyogs"]]); if (!empty($_POST[$GLOBALS["teeMKStMReeaqAoSOCuJ"]])){ $xmlDoc->col[$col]->dbname = $_POST[$GLOBALS["teeMKStMReeaqAoSOCuJ"]]; } if ($_POST[$GLOBALS["OqmFMVIWsbjbxDPrA"]]==$GLOBALS["WmndJmrTJdHCBhCnRXMB"]){ if (!$xmlDoc->col[$col]->dbname==$GLOBALS["tugkmwKQmrdyfghQnRJj"]){ $DB_TYPE = $xmlDoc->col[$col]->rdbms; if (isset($_POST[$GLOBALS["lmoCHwPemluShUKlVVrD"]])){ $DB_HOST = $GLOBALS["DWmsYJsvcfBZEyObOnZU"].$xmlDoc->col[$col]->servername; } else { $DB_HOST = $xmlDoc->col[$col]->servername; } $PORT=$GLOBALS["SnsSSwMKZSYeMFnEirnh"]; $DB_USER = $xmlDoc->col[$col]->username; $DB_PASS = passdescryption($xmlDoc->col[$col]->password); $DB_NAME = $xmlDoc->col[$col]->dbname; if (!empty(parse_url($DB_HOST, PHP_URL_PORT))) { $PORT = $GLOBALS["QkFZTTIeBvQdgwxtrjID"].parse_url($DB_HOST, PHP_URL_PORT).$GLOBALS["ZOlgKexAMiVzUOeICAxy"]; $DB_HOST=parse_url($DB_HOST, PHP_URL_HOST); } $SERVER=$GLOBALS["ZoqDfOutZhXDmAWQySwT"]; $DATABASE=$GLOBALS["teeMKStMReeaqAoSOCuJ"]; if ($DB_TYPE==$GLOBALS["oLnHtFxoAIZrAqrrMoBQ"]) { $SERVER=$GLOBALS["ZZUqLRTtOPEhDvABGXxH"]; $DATABASE=$GLOBALS["JmLHqpYcNjsSfaXglppE"]; } $xmlDoc->col[$col]->dbconnected = $GLOBALS["SHlRCNLzGtCGyHhhetLl"]; if ($DB_TYPE==$GLOBALS["JnsZplZErOzGpBDSQcnM"]){ $DB_HOST = $DB_HOST.$GLOBALS["JsPuQXopAGHsqRwURiUS"].$DB_NAME; $conn = oci_connect($DB_USER, $DB_PASS, $DB_HOST); if (!$conn) { $xmlDoc->col[$col]->dbconnected = $GLOBALS["aaVSngfyKHLQgxZvwrY"]; } } else { try{ if ($DB_TYPE==$GLOBALS["vHgqefPMUJbtZjbPIZVh"]){ if (file_exists($DB_NAME)){ if (filesize($DB_NAME) > 0 ) { $conn = new PDO($GLOBALS["SnsSSwMKZSYeMFnEirnh"].$DB_TYPE.$GLOBALS["JYNtVdTfHlgJkTOjMvtL"].$DB_NAME.$GLOBALS["SnsSSwMKZSYeMFnEirnh"]); } else { $xmlDoc->col[$col]->dbconnected = $GLOBALS["aaVSngfyKHLQgxZvwrY"]; } } else { $xmlDoc->col[$col]->dbconnected = $GLOBALS["aaVSngfyKHLQgxZvwrY"]; } } else if ($DB_TYPE==$GLOBALS["YEMYzLFpdvVCqlmCKKlF"]){ $conn = odbc_connect($SERVER, $DB_USER, $DB_PASS); } else { $conn = new PDO($GLOBALS["SnsSSwMKZSYeMFnEirnh"].$DB_TYPE.$GLOBALS["JYNtVdTfHlgJkTOjMvtL"].$SERVER.$GLOBALS["lhysjbAVbLipeHcOM"].$DB_HOST.$GLOBALS["yKJYEAspYGWeQuaPqCrJ"].$DATABASE.$GLOBALS["lhysjbAVbLipeHcOM"].$DB_NAME.$GLOBALS["cEnkzazMhFtVVgVOlaQm"].$PORT.$GLOBALS["SnsSSwMKZSYeMFnEirnh"], $DB_USER, $DB_PASS); } } catch(PDOException $e){ $xmlDoc->col[$col]->dbconnected = $e->getMessage(); } } } } if ($_POST[$GLOBALS["OqmFMVIWsbjbxDPrA"]]==$GLOBALS["NFHFxZiEQXOmAEpkqzsw"]){ if($_POST[$GLOBALS["qQmtIhpEGLBEGZtrwoxI"]]==$GLOBALS["mFGCSnEFevFdfjEaRs"]){ $xmlDoc->col[$col]->file = $_POST[$GLOBALS["rHfBnDikaoIpLTqSXWRS"]]; $xmlDoc->col[$col]->json = $GLOBALS["SnsSSwMKZSYeMFnEirnh"]; } if($_POST[$GLOBALS["qQmtIhpEGLBEGZtrwoxI"]]==$GLOBALS["CWkSJAwkFucZtXTBVUwH"]){ $xmlDoc->col[$col]->json = $_POST[$GLOBALS["zgfjWEwNNayMZBRdHrDM"]]; $xmlDoc->col[$col]->file=$GLOBALS["SnsSSwMKZSYeMFnEirnh"]; } if (basename($_FILES[$GLOBALS["BJfucULQDYxFBbgIdOQ"]][$GLOBALS["XckkIahjVOedVNldUNrH"]]) ) { $target_file = $GLOBALS["zIEKBWYDAoDgpOLxPwTc"] . basename($_FILES[$GLOBALS["BJfucULQDYxFBbgIdOQ"]][$GLOBALS["XckkIahjVOedVNldUNrH"]]); move_uploaded_file($_FILES[$GLOBALS["BJfucULQDYxFBbgIdOQ"]][$GLOBALS["PGnDVWIKgIUmFrZyuhhU"]], $target_file); $xmlDoc->col[$col]->file = $target_file; $xmlDoc->col[$col]->json = $GLOBALS["SnsSSwMKZSYeMFnEirnh"]; } if(!empty($_POST[$GLOBALS["GXlNvhDYmCGsWfqLMzpP"]])) { $xmlDoc->col[$col]->file = $_POST[$GLOBALS["GXlNvhDYmCGsWfqLMzpP"]]; $xmlDoc->col[$col]->json = $GLOBALS["SnsSSwMKZSYeMFnEirnh"]; } } $xmlDoc->asXML($xmlfile); } function passencryption ($string) { global $legacy; if ($legacy == $GLOBALS["VsESaojOTXdmcfrFhBgY"]) { return $string; } if (empty($string)) {return $string;} $ciphering = $GLOBALS["rTpZDGFNjBGeyajrbzA"]; $iv_length = openssl_cipher_iv_length($ciphering); $options = 0; $encryption_iv = $GLOBALS["mcnbxJZabxmxvnNJtAA"]; $encryption_key = $GLOBALS["JiSjXGwvCpsuVDsfnjcl"]; $encryption = openssl_encrypt($string, $ciphering, $encryption_key, $options, $encryption_iv); return $encryption; } function passdescryption ($encryption) { global $legacy; if ($legacy == $GLOBALS["VsESaojOTXdmcfrFhBgY"]) { return $encryption; } if (empty($encryption)) {return $encryption;} $ciphering = $GLOBALS["rTpZDGFNjBGeyajrbzA"]; $decryption_iv = $GLOBALS["mcnbxJZabxmxvnNJtAA"]; $decryption_key = $GLOBALS["JiSjXGwvCpsuVDsfnjcl"]; $options = 0; $decryption=openssl_decrypt ($encryption, $ciphering, $decryption_key, $options, $decryption_iv); return $decryption; } ?>


<script>

	document.getElementById('fileToUpload').required = false;
	$('#fileToUpload').get(0).setCustomValidity('');

	document.getElementById('google_url').required = false;
	$('#google_url').get(0).setCustomValidity('');

	document.getElementById('json_url').required = false;
	$('#json_url').get(0).setCustomValidity('');

function DBSelection() {

	var x = document.getElementById("rdbms").value;

	if(x === 'sqlite'){ //Check if SQLite is selected
            document.getElementById('hostID').style.display="none";
			document.getElementById('host').required = false;
			document.getElementById('userID').style.display="none";
			document.getElementById('user').required = false;
			document.getElementById('passwordID').style.display="none";
			$('#host').get(0).setCustomValidity('');
			$('#user').get(0).setCustomValidity('');
			document.getElementById('db-name').style.display="block";
			document.getElementById('ds-name').style.display="none";
			document.getElementById("dbname").setCustomValidity("<?php echo _TEXT[$GLOBALS["hLQZZQbYoLVVHuGcqiA"]];?>");
			} else 
			if(x === 'odbc'){ //Check if ODBC is selected
            document.getElementById('hostID').style.display="none";
			document.getElementById('host').required = false;
			document.getElementById('userID').style.display="block";
			document.getElementById('passwordID').style.display="block"; 
			document.getElementById('user').required = true;
			$('#host').get(0).setCustomValidity('');
			$('#user').get(0).setCustomValidity('');
			document.getElementById('db-name').style.display="none";
			document.getElementById('ds-name').style.display="block";	
			document.getElementById("dbname").setCustomValidity("");
			}
			else {
			document.getElementById('hostID').style.display="block";
			document.getElementById('host').required = true;
			document.getElementById('userID').style.display="block";
			document.getElementById('user').required = true;   
			document.getElementById('passwordID').style.display="block"; 
			document.getElementById('db-name').style.display="block";
			document.getElementById('ds-name').style.display="none";	
			document.getElementById('dbname').required = true;
			//document.getElementById("dbname").setCustomValidity("<?php echo _TEXT[$GLOBALS["hLQZZQbYoLVVHuGcqiA"]];?>");
			 }
}
</script>

<script type="text/javascript">
function tabvalue(tabvalue) {

	document.getElementById("source").value = tabvalue;

	if (tabvalue=='upload'){
		document.getElementById('host').required = false;
		document.getElementById('user').required = false;
		document.getElementById('dbname').required = false;
		$('#host').get(0).setCustomValidity('');
		$('#user').get(0).setCustomValidity('');
		$('#dbname').get(0).setCustomValidity('');
		
		//var e = document.getElementById("fileselect");
       // var strUser = e.options[e.selectedIndex].value;
		
		if ($('#fileselect').val() != null) {
			
			document.getElementById('pc').checked = true;
			document.getElementById('fileToUpload').required = false;
			document.getElementById('google_url').required = false;
			$('#fileToUpload').get(0).setCustomValidity('');
			$('#google_url').get(0).setCustomValidity('');
			
		} else if(document.getElementById('cloud').checked == true) {
			document.getElementById('fileToUpload').required = false;
			$('#fileToUpload').get(0).setCustomValidity('');
			$('#json').get(0).setCustomValidity('');
			document.getElementById('google_url').required = true;
		} else if(document.getElementById('json').checked == true) {
			document.getElementById('fileToUpload').required = false;
			$('#fileToUpload').get(0).setCustomValidity('');
			$('#google_url').get(0).setCustomValidity('');
			document.getElementById('json_url').required = true;
		} else {
		 <?php if (file_exists($xmlDoc->col[$col]->file)) { ?>
			document.getElementById('fileToUpload').required = false;
			$('#fileToUpload').get(0).setCustomValidity('');
		 <?php } else { ?>
			document.getElementById('fileToUpload').required = true;
		 <?php } ?>
			document.getElementById('google_url').required = false;
			$('#google_url').get(0).setCustomValidity('');
		}
		
	}
	
	if (tabvalue=='ADatabase'){
		document.getElementById('host').required = true;
		document.getElementById('user').required = true;
		document.getElementById('dbname').required = true;
		document.getElementById('fileToUpload').required = false;
		$('#fileToUpload').get(0).setCustomValidity('');
		DBSelection();
	}
}


$(document).ready(function () {
	
var x = document.getElementById("rdbms").value;

if(x === 'odbc'){ //Check if ODBC is selected
	document.getElementById('db-name').style.display="none";
	document.getElementById('ds-name').style.display="block";
	document.getElementById('host').required = false;	
	document.getElementById("host").setCustomValidity("");
}
 <?php if ($xmlDoc->col[$col]->source== $GLOBALS["NFHFxZiEQXOmAEpkqzsw"]) {?>
tabvalue('upload'); <?php }?>

$('input[type=file]').change(function () {
	var val = $(this).val().toLowerCase();
	var regex = new RegExp("(.*?)\.(csv|xlsx|xls)$");
	document.getElementById('pc').checked = true;
	document.getElementById('google_url').required = false;
	 if(!(regex.test(val))) {
		$(this).val('');
		document.getElementById("fileToUpload").setCustomValidity("<?php echo _TEXT[$GLOBALS["YluBnwWemDEeROGCAAnj"]];?>");
		} 
		tabvalue('upload');
	});
});

function google_url_f() {	
	document.getElementById('cloud').checked = true;
	document.getElementById("google_url").setCustomValidity("<?php echo _TEXT[$GLOBALS["xqggMhWPiQnZOGUOUyLc"]];?>");
	document.getElementById('fileToUpload').required = false;
	document.getElementById('json_url').required = false;
	$('#fileToUpload').get(0).setCustomValidity('');
	$('#fileselect').prop('selectedIndex', -1); //reset if file select
	tabvalue('upload');
}

function json_url_f() {	
	document.getElementById('json').checked = true;
	document.getElementById("json_url").setCustomValidity("<?php echo _TEXT[$GLOBALS["xqggMhWPiQnZOGUOUyLc"]];?>");
	document.getElementById('fileToUpload').required = false;
	document.getElementById('google_url').required = false;
	$('#fileToUpload').get(0).setCustomValidity('');
	$('#fileselect').prop('selectedIndex', -1); //reset if file select
	tabvalue('upload');
}

function fileselect_f() {
document.getElementById('pc').checked = true;
document.getElementById('fileToUpload').required = false;
document.getElementById('google_url').required = false;
document.getElementById('json_url').required = false;
$('#fileToUpload').get(0).setCustomValidity('');
$('#google_url').get(0).setCustomValidity('');
$('#json_url').get(0).setCustomValidity('');
tabvalue('upload');
}

</script>
